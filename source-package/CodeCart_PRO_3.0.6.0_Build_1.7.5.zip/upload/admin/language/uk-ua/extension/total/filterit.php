<?php
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

$_['heading_title'] = 'Filterit - НЕ ВСТАНОВЛЮЙТЕ ТА НЕ ВИДАЛЯЙТЕ!';