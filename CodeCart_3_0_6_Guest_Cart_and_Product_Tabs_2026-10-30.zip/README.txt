CodeCart 3.0.6 – guest cart contact script loading and product tab ordering.
Create a full backup of website files and database before installing.
Copy the upload/ folder to store root, preserving complete paths.
Clear OCMOD, Twig and OPcache where used.
Guest capture requires the abandoned cart feature and guest capture enabled, the standard cart source, valid email and explicit unchecked-by-default opt-in.
No consent means no collected contact and no abandoned-cart reminder.
The provided HTML sample is from rayzer.dk; barzus.com.ua is a separate installation.
