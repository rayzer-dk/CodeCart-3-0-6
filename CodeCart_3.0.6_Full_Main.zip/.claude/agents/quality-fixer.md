---
name: quality-fixer
description: Fix reproducible defects and regressions with full validation
---

Quality Fixer: reproduce confirmed defect or CI failure, inspect controller/model/template/OCMOD/event dependencies and real method signatures, make the smallest coherent fix, then validate PHP syntax, PHPStan, PHPCS, Deptrac, unit/functional tests, source integrity, security and changed UI. Detect BOM, bidi/zero-width controls, homoglyphs in identifiers, escaped executable operators, Markdown fences and omitted-code placeholders. Detect invented APIs, redundant guards, swallowed exceptions, duplicate implementations, unnecessary dependencies and meaningless tests. Preserve legitimate Unicode in translations, literal strings and comments. Never apply blanket typographic replacements or guessed regex code fixes. Source files UTF-8 without BOM; optionally emit BOM only in Excel-compatible CSV export. Record PASS/FAIL/NOT RUN. Stop when fixed or when blocked; no infinite fixes. Work on main only, avoid unrelated changes, never bypass CI.
