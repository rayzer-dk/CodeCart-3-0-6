CodeCart 3.0.6.0 - Abandoned Carts Update (31 October 2026)
Source: rayzer-dk/CodeCart-3-0-6, main d5568f9e1a1618d993b6266a94f0ea621f622575
Contents: 11 complete site files preserving upload/ paths.

IMPORTANT: Make a FULL backup of site files and the database before updating.
Compatible with the matching CodeCart 3.0.6.0 installation. Do not install on stock OpenCart or ocStore.
Recommended: apply to a staging copy first and perform real checkout and reminder tests.

INSTALLATION:
1. Extract archive locally. Copy the CONTENTS of upload/ into the CodeCart root using the included relative paths.
2. Overwrite only corresponding files. Do not delete the shopping cart, customer or order records.
3. Clear Twig/template and modifications caches, and PHP OPcache if enabled.
4. Open Sales -> Abandoned carts -> Settings. Review and SAVE your settings once without disabling desired functions.
5. Test guest checkout with explicit recovery opt-in; verify the contact row and the admin cart list.
6. Verify that orders, registrations, notification mails, automated jobs and other modules still operate.

FIXES:
- Capture consented guest contacts using the EXISTING native checkout consent checkbox before advancing checkout steps.
- Never collect guest contact details unless explicitly opted in; guest carts with no consent or no checkout input cannot be identified retrospectively.
- Keep opt-in data, eligible reminder queries and restoration consistent with configured 1 to 30 day history; default 7 days.
- Recovery links still have a seven-day validity and remain single-use.
- Inactive cart threshold accepts 1–10080 minutes; default 5 minutes, saved existing values preserved.
- Reminder delay displayed in minutes (5–10080, default 60), independent from idle threshold; Cron runs at five-minute cadence.
- Labels for the supported/automatic checkout mode remain neutral (popular templates), with manual URL for unsupported routes.
- Ukrainian, Russian and English labels and error help preserved.
- Sending by email still requires valid recipient, specific consent, permitted cart, active scheduler, and existing store Mail/SMTP settings.
- No unilateral switching-on of guest capture or mail sending; existing stored settings retained.

SECURITY: No unchecked guest consent or historical cart contacts are fabricated. Verify applicable privacy notices and permission to send reminders.
STATUS: ready after fixes. Targeted GitHub Actions passed on source commits; live site configuration, installed third-party checkout and production release gates not completely certified.
