CodeCart 3.0.6.0 - Mail Audit Read-Only Listing Update v1.0.1 (29 October 2026)

IMPORTANT: full backup of website files and database is mandatory before updating.
Only install on a matching CodeCart 3.0.6.0 installation with Mail Audit already present.
This is an incremental update: five changed files, not a complete CodeCart distribution.

INSTALL: copy contents of upload/ into website root, preserving folders and overwriting existing files.
Refresh OCMOD modifications and Twig cache if needed.
Admin > System > Settings > Mail > Mail Audit: click Refresh.
If the log reports missing table/columns, enable Audit and SAVE settings ONCE to create/update the DB table.
Mail Audit listing is read-only; it no longer creates or migrates SQL tables on every refresh.
Previously sent mail and existing audit records are not deleted.
If the log still fails, check its new DB error code and system storage/logs/error.log for 'Mail Audit listing failed'.
Do not change working SPF, DKIM or SMTP settings as part of this update.

LIMITATION: exact cause of HTTP 500 on the user's live site requires its PHP/DB error log.
Status: ready after fixes; test on staging before deploying to the live store.
