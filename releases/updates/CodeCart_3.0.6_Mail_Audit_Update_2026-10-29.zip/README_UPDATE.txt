CodeCart 3.0.6.0 Mail Audit and anti-spam upgrade, patch v3, 2026-10-29
BACK UP all website files and the database before upgrading.
Only for matching CodeCart 3.0.6.0; NOT for stock OpenCart/ocStore.
Install on staging first. Copy the CONTENTS of upload/ over the site root; preserve directories.
Refresh modifications and Twig cache as applicable; verify checkout and outgoing mail.
Admin: System > Settings > Mail: enable Mail Audit and SAVE. Default is OFF.
Upgrades previous audit tables in place, retaining all existing records.
DKIM field accepts up to 5 selectors separated by commas; a missing selector does not prove the domain has no DKIM.
DNS checks operate on the sender email domain of this shop; verify correct shop email.
Test PHP Mail or SMTP only on explicit button press; test result is transport acceptance not inbox delivery.
Mail Audit monitors the CodeCart Mail class plus selected blocked form events, not arbitrary bots or direct PHP mail() calls.
Audit does not prevent sending client/admin notifications and does not store message bodies or secrets.
All three translations: en-gb, ru-ru, uk-ua. Status ready after fixes: production upgrade QA not fully green.
