CodeCart 3.0.6.0 | Mail Audit + form anti-spam patch
Source: rayzer-dk/CodeCart-3-0-6
Scope: 23 added/changed files since b4dc3ebd10000bee7397487dfdd530702c04dd14
Date: 2026-10-29

INSTALLATION
1. Back up ALL site files and database. Confirm your installation is CodeCart 3.0.6.0 (not stock OpenCart/ocStore).
2. Extract ZIP locally; upload the CONTENTS of folder upload/ into the CodeCart web root, preserving folders and overwriting changed files.
3. Refresh Modifications, clear template cache, confirm storefront and admin are functional.
4. Admin > System > Settings > Mail > Mail Audit: set enabled, save. The audit table is created on first enable.
5. Optionally test PHP Mail/SMTP using the manual test buttons. Tests send ONLY when clicked.

FEATURES
- Metadata-only outgoing message log: sender, recipient, subject, store, source, IP and PHP Mail/SMTP transport result.
- Separate blocked-attempt events for contact, customer, affiliate, return, checkout registration and product/blog review forms.
- Rate-limit hardening for public review forms, checkout registration and vouchers.
- DNS SPF/DMARC/DKIM TXT lookup (selector configurable), plus explicit Mail/SMTP transport tests.
- SMTP password masked by default, visible using the eye button.
- 30-day log retention; initial state OFF; no email body or SMTP credentials stored in audit.

IMPORTANT LIMITATIONS
- Accepted by transport does NOT mean delivered to inbox.
- DNS DKIM key existence does NOT prove that PHP Mail or SMTP signs outgoing emails. Check DKIM-Signature/Authentication-Results in received test headers.
- Blocked events cover code paths instrumented for rate limits and CAPTCHA, not all HTTP bot traffic.
- Third-party or compromised PHP scripts calling mail() outside the CodeCart Mail class cannot be monitored by this patch.
- Third-party themes and modules may implement additional forms; audit them separately on the live site.
- No installation on the production site has been performed. Full QA on the live configuration remains pending.

STATUS: ready after fixes (not yet production-certified).
