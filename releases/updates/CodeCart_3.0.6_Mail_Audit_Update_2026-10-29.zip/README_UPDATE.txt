CodeCart 3.0.6.0 | Mail Audit and anti-spam patch v2
Source: rayzer-dk/CodeCart-3-0-6
Updated: 2026-10-29; commit aa0319a522d75236a1335ccbab64a1fb43455436
Contents: 23 changed/new upload files; replaces the earlier patch ZIP.

INSTALLATION
1. Create complete backup of website files AND database; test on staging first.
2. Use ONLY with the matching CodeCart 3.0.6.0 distribution. Not for stock ocStore/OpenCart.
3. Copy CONTENTS of upload/ over the CodeCart website root, preserving paths.
4. Refresh modifications and templates; verify checkout, notification and mail settings.
5. System > Settings > Mail: enable Mail Audit and save. OFF by default.
6. Manual PHP Mail/SMTP test sends a message to the store email only when clicked.

MAIL AUDIT
- Per-message sender, recipient, subject, store, transport, source, result and IP.
- Aggregate counts by form/source and transport status for the last 30 days.
- Repeated blocked attempts aggregated by IP/source/reason in 5-minute buckets.
- Captcha/rate-limit blocks from instrumented first-party forms, not every HTTP bot request.
- Three language admin labels: en-gb, ru-ru, uk-ua.
- Logs do NOT contain message bodies, passwords or tokens.
- A successful transport result is not an inbox-delivery receipt.
- SPF, DMARC, DKIM DNS check does not prove an outgoing message carries a valid DKIM signature.
- Do not modify SMTP credentials to enable auditing.
- Third-party modules calling OpenCart Mail are audited; external PHP mail() calls are not.
- Anti-spam limits apply to public forms, NOT internal module mail notifications.
- Keep a copy of the previous version for rollback.

STATUS: ready after fixes; not production-certified on your live site. Upgrade QA suites are not fully green.
