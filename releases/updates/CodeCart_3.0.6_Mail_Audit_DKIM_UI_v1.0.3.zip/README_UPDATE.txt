CodeCart 3.0.6 - Mail Audit DKIM DNS Button Layout Update v1.0.3
Date: 2026-10-29
Repository: rayzer-dk/CodeCart-3-0-6
Source commit: 4da66e9d217388085f931b8dcc63dd47c24f2705

CAUTION: Back up your website files and database first.
Compatible with the installed CodeCart 3.0.6 Mail Audit settings, not stock OpenCart/ocStore.
Test on a staging site before production.

Install: unzip and upload contents of upload/ over the corresponding website files.
Refresh OpenCart modifications and clear Twig/theme cache, then reload the admin settings page.
If a CDN or browser cache retains old stylesheet.css, clear that cache and hard-reload the page.

Changes:
- Remove incorrect hardcoded 34px height from the DKIM DNS check button.
- Add uniquely scoped flex alignment rules so button and selector input stretch to identical height.
- Scoped rules do not alter other buttons, forms, transport behavior or mail logging.
- CSS is appended to the existing administrator stylesheet; no new external assets are loaded.

Browser validation: Chromium desktop/tablet/mobile width 320/650/1200 px with 38px admin input height: both controls measured 38px and aligned.
Full integration and production store tests remain to be performed.
Status: ready after fixes.
