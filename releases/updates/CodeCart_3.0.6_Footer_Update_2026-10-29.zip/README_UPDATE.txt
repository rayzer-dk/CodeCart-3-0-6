CodeCart 3.0.6.0 - Administration Footer Two-Row Update
Date: 2026-10-29
Source: rayzer-dk/CodeCart-3-0-6 main commit 330e3cb81f33d60f77002b3c1ceafc6e52e84286

IMPORTANT: Create a FULL backup of website files and database before installing.
Compatibility: only an existing CodeCart 3.0.6.0 installation with the matching footer.
This is a direct-file update package, not an OCMOD installation.

INSTALLATION:
1. Prefer a staging website; verify the footer after replacement.
2. Extract this ZIP and copy the CONTENTS of upload/ over the CodeCart root.
3. Preserve subdirectories and overwrite only matching target files.
4. Clear compiled Twig/template cache and refresh OCMOD modifications if applicable.
5. Reload the admin page (Ctrl+F5). Header stylesheet URL has a new cache-busting suffix.

CHANGES:
- Exactly two logical footer rows: brand/links, then system summary.
- Increase vertical separation and line height between rows.
- Remove obsolete expandable System details control and its language labels.
- Show Web server: Apache, Nginx, LiteSpeed, OpenResty, Caddy, lighttpd or IIS.
- Expose only the web-server family, not its precise software build/version.
- Keep PHP version, MariaDB/MySQL version, utf8mb4, ionCube (if enabled), and server time.
- Preserve support links, modals, responsive layout, dark mode and authenticated visibility.
- Three admin language packs: en-gb, ru-ru, uk-ua.
- No changes to email transport, settings or user data.

TESTS: tests/admin_footer_runtime_smoke.php updated in GitHub main.
Status: see GitHub Actions for the same main commit; production-site test remains necessary.
