CodeCart 3.0.6.0 - Abandoned Cart Settings & History Update
Date: 2026-10-29
Source: rayzer-dk/CodeCart-3-0-6 main 0345b3579c015426ddc2e04f753a56aafdf567a1

Important: FULL BACKUP of website files and database before installation.
Apply to CodeCart 3.0.6 with the corresponding existing abandoned-cart implementation.
Do not use with unmodified OpenCart/ocStore or overwrite custom checkout modifications blindly.

INSTALL: extract ZIP, then copy only the contents of upload/ over the CodeCart website root, preserving folders.
Refresh modifications and clear compiled Twig/template cache after deployment.
Visit Sales > Abandoned carts > Settings and review current saved values.

CHANGES
- Inactivity min 1 minute; default 5 minutes on NEW installs. Existing saved settings are intentionally preserved.
- History 1-30 days; default 7 days. Standard guest-cart cleanup matches selected history while feature is enabled.
- Independent reminder delay 5-10080 minutes; default 60. No reminder before inactivity threshold.
- Internal scheduled Cron retains 5 minute cadence; actual notification can occur later than the delay.
- Automatic reminders still require cart-specific explicit consent, valid email, known storefront and are limited to carts <=7 days old.
- Emails and identities for guests who never entered checkout or never opted in cannot be recovered after the fact.
- Email/guest consent records still expire after 7 days even when cart-line history is extended to 30 days.
- Label for checkout mode is neutral; popular themes use automatic detection when supported, otherwise custom URL.
- Updated translations en-gb, ru-ru and uk-ua.
- No changes to system email transport or other module mail sending.

VERIFY: Enable abandoned-cart analytics & guest capture as appropriate, test in staging:
  (1) Guest adds item without visiting checkout: name/email remain unavailable, no email sent.
  (2) Guest opts in at a supported checkout with name/email: the contact appears after a few minutes.
  (3) No consent: sending remains disabled.
  (4) Reminder delay > idle: no premature email; existing 5-min Cron sends only after delay.
  (5) At most one reminder in 24 hours. Mail history and other sales functions remain intact.
  (6) Increasing history does not recover carts already deleted by prior cleanup.

Status: ready after fixes; live checkout and scheduled Cron E2E not verified.
