CodeCart 3.0.6 - Mail Audit Summary SQL and DKIM Button Alignment v1.0.2
Updated on 2026-10-29

IMPORTANT: Back up website files and database before installing.
Compatible only with an existing CodeCart 3.0.6 installation that already has Mail Audit.
Do NOT use on stock OpenCart or ocStore.

Installation: extract ZIP and copy the CONTENTS of upload/ over the CodeCart site root, replacing only two corresponding files.
Then refresh modifications and Twig template cache.
Open System > Settings > Mail > Mail Audit and click Refresh.
No database schema changes or mail delivery settings changes are required.

Fixes:
 - MySQL/MariaDB 1247 error in per-form aggregate statistics sorting.
 - Align DNS Check button with selector field (34px).
 - No changes to existing mail transport, SMTP settings or spam-rate limits.

If statistics still fail, check system/storage/logs/error.log for Mail Audit summary failed and its SQL error code.
Status: ready after fixes - production site test required; existing release gates not all green.
