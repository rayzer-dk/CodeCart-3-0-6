<?php
// Heading
$_['heading_title']		 = 'LIQPAY';

// Text
$_['text_extension']	 = 'Extensions';
$_['text_success']		 = 'Success: You have modified LIQPAY account details!';
$_['text_edit']          = 'Edit LIQPAY';
$_['text_pay']			 = 'LIQPAY';
$_['text_card']			 = 'Credit Card';
$_['text_liqpay']		 = '<img src="view/image/payment/liqpay.png" alt="LIQPAY" title="LIQPAY" style="border: 1px solid #EEEEEE;" />';

// Entry
$_['entry_merchant']	 = 'Merchant ID';
$_['entry_signature']	 = 'Signature';
$_['entry_type']		 = 'Type';
$_['entry_total']		 = 'Total';
$_['entry_order_status'] = 'Order Status';
$_['entry_geo_zone']	 = 'Geo Zone';
$_['entry_status']		 = 'Status';
$_['entry_sort_order']	 = 'Sort Order';

// Help
$_['help_total']		 = 'The checkout total the order must reach before this payment method becomes active.';

// Error
$_['error_permission']	 = 'Warning: You do not have permission to modify payment LIQPAY!';
$_['error_merchant']	 = 'Merchant ID Required!';
$_['error_signature']	 = 'Signature Required!';
$_['entry_public_key'] = 'Public key';
$_['entry_private_key'] = 'Private key';
$_['entry_sandbox'] = 'Sandbox mode';
$_['button_show_secret'] = 'Show / hide private key';
$_['error_public_key'] = 'Public key is required';
$_['error_private_key'] = 'Private key is required';

// CodeCart PRO: aligned locale keys
$_['text_payment'] = 'Payment';
