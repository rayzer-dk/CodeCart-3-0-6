<?php
// Heading
$_['heading_title']    = 'Account';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified account module!';
$_['text_edit']        = 'Edit Account Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify account module!';
$_['entry_collapsed_mobile'] = 'Collapse on mobile';

// CodeCart PRO: aligned locale keys
$_['text_module'] = 'Modules';
