<?php
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']       = 'Layouts';

// Text
$_['text_success']        = 'Success: You have modified layouts!';
$_['text_list']           = 'Layout List';
$_['text_add']            = 'Add Layout';
$_['text_edit']           = 'Edit Layout';
$_['text_move']           = 'You can move and reorder modules position';
$_['text_remove']         = 'Remove';
$_['text_route']          = 'Choose the store and routes to be used with this layout';
$_['text_module']         = 'Choose the position of the modules';
$_['text_default']        = 'Default';
$_['text_content_top']    = 'Content Top';
$_['text_content_bottom'] = 'Content Bottom';
$_['text_column_left']    = 'Column Left';
$_['text_column_right']   = 'Column Right';

// Column
$_['column_name']         = 'Layout Name';
$_['column_action']       = 'Action';

// Entry
$_['entry_name']          = 'Layout Name';
$_['entry_store']         = 'Store';
$_['entry_route']         = 'Route';
$_['entry_module']        = 'Module';

// Error
$_['error_permission']    = 'Warning: You do not have permission to modify layouts!';
$_['error_name']          = 'Layout Name must be between 3 and 64 characters!';
$_['error_default']       = 'Warning: This layout cannot be deleted as it is currently assigned as the default store layout!';
$_['error_store']         = 'Warning: This layout cannot be deleted as it is currently assigned to %s stores!';
$_['error_product']       = 'Warning: This layout cannot be deleted as it is currently assigned to %s products!';
$_['error_category']      = 'Warning: This layout cannot be deleted as it is currently assigned to %s categories!';
$_['error_manufacturer']  = 'Warning: This layout cannot be deleted as it is currently assigned to %s manufacturers!';
$_['error_information']   = 'Warning: This layout cannot be deleted as it is currently assigned to %s information pages!';
// CodeCart PRO: aligned locale keys
$_['entry_position'] = 'Position';
$_['entry_sort_order'] = 'Sort Order';
$_['error_blog_article'] = 'This layout is assigned to %s blog articles and cannot be deleted.';
$_['error_blog_category'] = 'This layout is assigned to %s blog categories and cannot be deleted.';
