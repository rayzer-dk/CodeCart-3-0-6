<?php
// CodeCart PRO ru-ru language pack. Missing keys fall back to en-gb.
$_['heading_title'] = 'Производители';
$_['text_success'] = 'Настройки успешно изменены!';
$_['text_list'] = 'Список производителей';
$_['text_add'] = 'Добавить';
$_['text_edit'] = 'Редактирование';
$_['text_default'] = 'По умолчанию';
$_['text_percent'] = 'Процент';
$_['text_amount'] = 'Фиксированная сумма';
$_['text_keyword'] = 'Должен быть уникальным на всю систему, без пробелов и спецсимволов.';
$_['column_name'] = 'Название производителя';
$_['column_sort_order'] = 'Порядок сортировки';
$_['column_noindex'] = 'Индексация';
$_['column_action'] = 'Действие';
$_['entry_name'] = 'Название производителя';
$_['entry_meta_h1'] = 'HTML-тег H1';
$_['entry_description'] = 'Описание:';
$_['entry_meta_title'] = 'Мета-тег Title';
$_['entry_meta_keyword'] = 'Мета-тег Keywords';
$_['entry_meta_description'] = 'Мета-тег Description';
$_['entry_store'] = 'Магазины';
$_['entry_keyword'] = 'SEO URL';
$_['entry_image'] = 'Изображение';
$_['entry_sort_order'] = 'Порядок сортировки';
$_['entry_type'] = 'Тип';
$_['entry_noindex'] = 'Индексация';
$_['entry_related_mn'] = 'Рекомендуемые товары:';
$_['entry_related_article'] = 'Рекомендуемые статьи:';
$_['entry_layout'] = 'Изменить макет';
$_['tab_design'] = 'Дизайн';
$_['help_related'] = '(Автозаполнение)';
$_['error_permission'] = 'У вас недостаточно прав для внесения изменений!';
$_['error_name'] = 'Название должно содержать от 2 до 64 символов!';
$_['error_keyword'] = 'SEO URL уже используется!';
$_['error_unique'] = 'SEO URL должен быть уникальным!';
$_['error_product'] = 'Этого производителя нельзя удалить так как он используется в %s товарах!';
$_['button_generate_seo_url'] = 'Сгенерировать SEO URL';
$_['error_meta_title'] = 'Мета-тег Title должен содержать от 0 до 255 символов!';
$_['error_meta_h1'] = 'HTML-тег H1 должен содержать от 0 до 255 символов!';

// CodeCart PRO: aligned locale keys
$_['entry_description_bottom'] = 'Описание внизу:';
$_['error_warning'] = 'Внимательно проверьте форму на ошибки!';
$_['help_keyword'] = 'Должен быть уникальным во всей системе, без пробелов и спецсимволов';
$_['help_noindex'] = 'Индексация поисковыми системами Google, Yandex, Bing и др.';
