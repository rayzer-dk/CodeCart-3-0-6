<?php
// CodeCart PRO ru-ru language pack. Missing keys fall back to en-gb.
$_['heading_title'] = 'Опции';
$_['text_success'] = 'Настройки успешно изменены!';
$_['text_list'] = 'Список опций';
$_['text_add'] = 'Добавить';
$_['text_edit'] = 'Редактирование';
$_['text_choose'] = 'Выбор';
$_['text_select'] = 'Список';
$_['text_radio'] = 'Переключатель';
$_['text_checkbox'] = 'Флажок';
$_['text_input'] = 'Поле ввода';
$_['text_text'] = 'Текст';
$_['text_textarea'] = 'Текстовая область';
$_['text_file'] = 'Файл';
$_['text_date'] = 'Дата';
$_['text_datetime'] = 'Дата и время';
$_['text_time'] = 'Время';
$_['text_option'] = 'Опция';
$_['text_value'] = 'Значения опций';
$_['column_name'] = 'Название опции';
$_['column_sort_order'] = 'Порядок сортировки';
$_['column_action'] = 'Действие';
$_['entry_name'] = 'Название опции';
$_['entry_type'] = 'Тип';
$_['entry_option_value'] = 'Значение опции';
$_['entry_image'] = 'Изображение';
$_['entry_sort_order'] = 'Порядок сортировки';
$_['error_permission'] = 'У вас недостаточно прав для внесения изменений!';
$_['error_name'] = 'Название должно содержать от 1 до 128 символов!';
$_['error_type'] = 'Не указано значение!';
$_['error_option_value'] = 'Значение должно содержать от 1 до 128!';
$_['error_product'] = 'Эту опцию нельзя удалить, так как она используется в %s товарах!';

// CodeCart PRO: aligned locale keys
$_['text_image'] = 'Изображения';
