# CodeCart 3.0.6 documentation
[Українська](README.uk.md) · [Project](../README.md) · [Join the CodeCart PRO community](https://t.me/codecartpro)

CodeCart is a free, open-source online store CMS with an adaptive theme, native multilingual SEO URLs, order and catalog management, public product documents and an OpenCart-compatible extension framework. See the [full platform description](../README.md).

**Create and verify a complete website and database backup before installation or update.** Use the production package with bundled dependencies; deploy only `upload/` contents.

| Guide | English | Українська |
|---|---|---|
| New store | [Installation](INSTALL.md) | [Встановлення](INSTALL.uk.md) |
| Existing store | [Upgrade and repair](UPGRADE.md) | [Оновлення та відновлення](UPGRADE.uk.md) |
| Hosting | [nginx + PHP-FPM](NGINX.md) | [nginx + PHP-FPM](NGINX.uk.md) |
| Platform compatibility | [Compatibility](COMPATIBILITY.md) | [Сумісність](COMPATIBILITY.uk.md) |
| Automation | [Scheduler](SCHEDULER.md) | [Планувальник](SCHEDULER.uk.md) |
| Missing content | [Lost URLs and manual redirects](LOST_URLS.md) | [Втрачені URL та ручні редиректи](LOST_URLS.uk.md) |
| Storefront errors | [Error pages](ERROR_PAGES.md) | [Сторінки помилок](ERROR_PAGES.uk.md) |
| Developers | [Compatibility Framework](COMPATIBILITY_FRAMEWORK.md) | [Compatibility Framework](COMPATIBILITY_FRAMEWORK.uk.md) |
| Source publishing | [GitHub](GITHUB.md) | [GitHub](GITHUB.uk.md) |

Canonical source: [CodeCartPro/CodeCartPro-3.0.6.0](https://github.com/CodeCartPro/CodeCartPro-3.0.6.0). Support: [support@codecartpro.com](mailto:support@codecartpro.com). Discuss installation and improvements in the [CodeCart PRO community](https://t.me/codecartpro).

[Demo storefront and administrator access](DEMO.md)

