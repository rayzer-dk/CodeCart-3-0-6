CodeCart 3.0.6 - all files changed since the start of this chat.
Source: the main branch at the same revision as the complete ZIP.
Before updating, back up the full website and database.
Files under upload/ replace their matching OpenCart/CodeCart paths.
.github/workflows/ and tools/ are source/developer checks, not site files.

Scheduler 500 safety: the controller now tolerates an older
SystemNotification during partial updates and logs the original failure.
Deploy the matching upload/system/library/codecart/src/SystemNotification.php
as well as upload/admin/controller/tool/scheduler.php, then refresh PHP
OPcache. The previous missing method caused HTTP 500.

The product price/quantity edit now happens inside the selected cell.
Refresh OCMOD, Twig and browser cached assets after updating.
Log header buttons are equal 38x38; Copy has a yellow background.
Abandoned cart retention supports up to 30 days.

Historic SEOPRO and EU Cookie Consent module warnings in the supplied
application log are separate faults and are not fixed by this update.
