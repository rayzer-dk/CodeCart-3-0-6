<?php
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

class ModelCatalogCategory extends Model {
	public function addCategory($data) {
		$google_product_category_id = preg_replace('/[^0-9]/', '', (string)($data['google_product_category_id'] ?? ''));
		$this->db->query("INSERT INTO " . DB_PREFIX . "category SET parent_id = '" . (int)$data['parent_id'] . "', `top` = '" . (isset($data['top']) ? (int)$data['top'] : 0) . "', `column` = '" . (int)$data['column'] . "', sort_order = '" . (int)$data['sort_order'] . "', status = '" . (int)$data['status'] . "', noindex = '" . (int)$data['noindex'] . "', google_product_category_id = '" . $this->db->escape($google_product_category_id) . "', date_modified = NOW(), date_added = NOW()");

		$category_id = $this->db->getLastId();

		if (isset($data['image'])) {
			$this->db->query("UPDATE " . DB_PREFIX . "category SET image = '" . $this->db->escape($data['image']) . "' WHERE category_id = '" . (int)$category_id . "'");
		}

		foreach ($data['category_description'] as $language_id => $value) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "category_description SET category_id = '" . (int)$category_id . "', language_id = '" . (int)$language_id . "', name = '" . $this->db->escape($value['name']) . "', description = '" . $this->db->escape(\CodeCart\Core\SafeRichHtml::sanitize(isset($value['description']) ? $value['description'] : '')) . "', meta_title = '" . $this->db->escape($value['meta_title']) . "', meta_h1 = '" . $this->db->escape($value['meta_h1']) . "', meta_description = '" . $this->db->escape($value['meta_description']) . "', meta_keyword = '" . $this->db->escape($value['meta_keyword']) . "'");
		}

		// MySQL Hierarchical Data Closure Table Pattern
		$level = 0;

		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "category_path` WHERE category_id = '" . (int)$data['parent_id'] . "' ORDER BY `level` ASC");

		foreach ($query->rows as $result) {
			$this->db->query("INSERT INTO `" . DB_PREFIX . "category_path` SET `category_id` = '" . (int)$category_id . "', `path_id` = '" . (int)$result['path_id'] . "', `level` = '" . (int)$level . "'");

			$level++;
		}

		$this->db->query("INSERT INTO `" . DB_PREFIX . "category_path` SET `category_id` = '" . (int)$category_id . "', `path_id` = '" . (int)$category_id . "', `level` = '" . (int)$level . "'");

		if (isset($data['category_filter'])) {
			foreach ($data['category_filter'] as $filter_id) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "category_filter SET category_id = '" . (int)$category_id . "', filter_id = '" . (int)$filter_id . "'");
			}
		}

		if (isset($data['category_store'])) {
			foreach ($data['category_store'] as $store_id) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "category_to_store SET category_id = '" . (int)$category_id . "', store_id = '" . (int)$store_id . "'");
			}
		}
		
		if ($this->config->get('config_auto_seo_url')) {
			$seo_names = array();
			foreach ($data['category_description'] as $language_id => $value) {
				if (!empty($value['name'])) { $seo_names[(int)$language_id] = $value['name']; }
			}
			$data['category_seo_url'] = codecart_fill_new_seo_urls($this->db, isset($data['category_seo_url']) ? $data['category_seo_url'] : array(), $seo_names, isset($data['category_store']) ? $data['category_store'] : array(0));
		}

		if (isset($data['category_seo_url'])) {
			foreach ($data['category_seo_url'] as $store_id => $language) {
				foreach ($language as $language_id => $keyword) {
					if (!empty($keyword)) {
						$this->db->query("INSERT INTO " . DB_PREFIX . "seo_url SET store_id = '" . (int)$store_id . "', language_id = '" . (int)$language_id . "', query = 'category_id=" . (int)$category_id . "', keyword = '" . $this->db->escape(trim($keyword)) . "'");
					}
				}
			}
		}
		
		if (isset($data['product_related'])) {
			$related_values = array();
			foreach (array_unique(array_map('intval', (array)$data['product_related'])) as $related_id) {
				$related_values[] = "('" . (int)$category_id . "', '" . $related_id . "')";
			}
			if ($related_values) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "product_related_wb (category_id, product_id) VALUES " . implode(', ', $related_values));
			}
		}
	
		if (isset($data['article_related'])) {
			$related_values = array();
			foreach (array_unique(array_map('intval', (array)$data['article_related'])) as $related_id) {
				$related_values[] = "('" . (int)$category_id . "', '" . $related_id . "')";
			}
			if ($related_values) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "article_related_wb (category_id, article_id) VALUES " . implode(', ', $related_values));
			}
		}
		
		// Set which layout to use with this category
		if (isset($data['category_layout'])) {
			foreach ($data['category_layout'] as $store_id => $layout_id) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "category_to_layout SET category_id = '" . (int)$category_id . "', store_id = '" . (int)$store_id . "', layout_id = '" . (int)$layout_id . "'");
			}
		}

		$this->saveCategoryPurchaseBlocks($category_id, $data);

		$this->cache->delete('category');
		$this->cache->deleteTag('catalog.category_counts', 'category_product_counts');
		
		if($this->config->get('config_seo_pro')){		
		$this->cache->delete('seopro');
		}

		return $category_id;
	}

	public function editCategory($category_id, $data) {
		try { (new \CodeCart\Core\RelationLayer($this->registry))->invalidateProductRulesByCategory((int)$category_id); } catch (\Throwable $e) { $this->log->write('Relation invalidate category: ' . $e->getMessage()); }
		$google_product_category_id = preg_replace('/[^0-9]/', '', (string)($data['google_product_category_id'] ?? ''));
		$this->db->query("UPDATE " . DB_PREFIX . "category SET parent_id = '" . (int)$data['parent_id'] . "', `top` = '" . (isset($data['top']) ? (int)$data['top'] : 0) . "', `column` = '" . (int)$data['column'] . "', sort_order = '" . (int)$data['sort_order'] . "', status = '" . (int)$data['status'] . "', noindex = '" . (int)$data['noindex'] . "', google_product_category_id = '" . $this->db->escape($google_product_category_id) . "', date_modified = NOW() WHERE category_id = '" . (int)$category_id . "'");

		if (isset($data['image'])) {
			$this->db->query("UPDATE " . DB_PREFIX . "category SET image = '" . $this->db->escape($data['image']) . "' WHERE category_id = '" . (int)$category_id . "'");
		}

		$this->db->query("DELETE FROM " . DB_PREFIX . "category_description WHERE category_id = '" . (int)$category_id . "'");

		foreach ($data['category_description'] as $language_id => $value) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "category_description SET category_id = '" . (int)$category_id . "', language_id = '" . (int)$language_id . "', name = '" . $this->db->escape($value['name']) . "', description = '" . $this->db->escape(\CodeCart\Core\SafeRichHtml::sanitize(isset($value['description']) ? $value['description'] : '')) . "', meta_title = '" . $this->db->escape($value['meta_title']) . "', meta_h1 = '" . $this->db->escape($value['meta_h1']) . "', meta_description = '" . $this->db->escape($value['meta_description']) . "', meta_keyword = '" . $this->db->escape($value['meta_keyword']) . "'");
		}

		// MySQL Hierarchical Data Closure Table Pattern
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "category_path` WHERE path_id = '" . (int)$category_id . "' ORDER BY level ASC");

		if ($query->rows) {
			// The new parents are the same for every node of the moved subtree.
			$parent_path = array();
			$parent_query = $this->db->query("SELECT path_id FROM `" . DB_PREFIX . "category_path` WHERE category_id = '" . (int)$data['parent_id'] . "' ORDER BY level ASC");

			foreach ($parent_query->rows as $result) {
				$parent_path[] = (int)$result['path_id'];
			}

			foreach ($query->rows as $category_path) {
				// Delete the path below the current one
				$this->db->query("DELETE FROM `" . DB_PREFIX . "category_path` WHERE category_id = '" . (int)$category_path['category_id'] . "' AND level < '" . (int)$category_path['level'] . "'");

				$path = $parent_path;

				// Get whats left of the nodes current path
				$remaining_query = $this->db->query("SELECT path_id FROM `" . DB_PREFIX . "category_path` WHERE category_id = '" . (int)$category_path['category_id'] . "' ORDER BY level ASC");

				foreach ($remaining_query->rows as $result) {
					$path[] = (int)$result['path_id'];
				}

				// Combine the paths with a new level
				$values = array();

				foreach ($path as $level => $path_id) {
					$values[] = "('" . (int)$category_path['category_id'] . "', '" . (int)$path_id . "', '" . (int)$level . "')";
				}

				$this->db->query("REPLACE INTO `" . DB_PREFIX . "category_path` (category_id, path_id, level) VALUES " . implode(', ', $values));
			}
		} else {
			// Delete the path below the current one
			$this->db->query("DELETE FROM `" . DB_PREFIX . "category_path` WHERE category_id = '" . (int)$category_id . "'");

			// Fix for records with no paths
			$level = 0;

			$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "category_path` WHERE category_id = '" . (int)$data['parent_id'] . "' ORDER BY level ASC");

			foreach ($query->rows as $result) {
				$this->db->query("INSERT INTO `" . DB_PREFIX . "category_path` SET category_id = '" . (int)$category_id . "', `path_id` = '" . (int)$result['path_id'] . "', level = '" . (int)$level . "'");

				$level++;
			}

			$this->db->query("REPLACE INTO `" . DB_PREFIX . "category_path` SET category_id = '" . (int)$category_id . "', `path_id` = '" . (int)$category_id . "', level = '" . (int)$level . "'");
		}

		$this->db->query("DELETE FROM " . DB_PREFIX . "category_filter WHERE category_id = '" . (int)$category_id . "'");

		if (isset($data['category_filter'])) {
			foreach ($data['category_filter'] as $filter_id) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "category_filter SET category_id = '" . (int)$category_id . "', filter_id = '" . (int)$filter_id . "'");
			}
		}

		$this->db->query("DELETE FROM " . DB_PREFIX . "category_to_store WHERE category_id = '" . (int)$category_id . "'");

		if (isset($data['category_store'])) {
			foreach ($data['category_store'] as $store_id) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "category_to_store SET category_id = '" . (int)$category_id . "', store_id = '" . (int)$store_id . "'");
			}
		}

		// SEO URL
		$this->db->query("DELETE FROM `" . DB_PREFIX . "seo_url` WHERE query = 'category_id=" . (int)$category_id . "'");

		if (isset($data['category_seo_url'])) {
			foreach ($data['category_seo_url'] as $store_id => $language) {
				foreach ($language as $language_id => $keyword) {
					if (!empty($keyword)) {
						$this->db->query("INSERT INTO " . DB_PREFIX . "seo_url SET store_id = '" . (int)$store_id . "', language_id = '" . (int)$language_id . "', query = 'category_id=" . (int)$category_id . "', keyword = '" . $this->db->escape(trim($keyword)) . "'");
					}
				}
			}
		}
		
		$this->db->query("DELETE FROM " . DB_PREFIX . "product_related_wb WHERE category_id = '" . (int)$category_id . "'");
	
		if (isset($data['product_related'])) {
			$related_values = array();
			foreach (array_unique(array_map('intval', (array)$data['product_related'])) as $related_id) {
				$related_values[] = "('" . (int)$category_id . "', '" . $related_id . "')";
			}
			if ($related_values) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "product_related_wb (category_id, product_id) VALUES " . implode(', ', $related_values));
			}
		}
		
		$this->db->query("DELETE FROM " . DB_PREFIX . "article_related_wb WHERE category_id = '" . (int)$category_id . "'");
	
		if (isset($data['article_related'])) {
			$related_values = array();
			foreach (array_unique(array_map('intval', (array)$data['article_related'])) as $related_id) {
				$related_values[] = "('" . (int)$category_id . "', '" . $related_id . "')";
			}
			if ($related_values) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "article_related_wb (category_id, article_id) VALUES " . implode(', ', $related_values));
			}
		}
		
		$this->db->query("DELETE FROM " . DB_PREFIX . "category_to_layout WHERE category_id = '" . (int)$category_id . "'");

		if (isset($data['category_layout'])) {
			foreach ($data['category_layout'] as $store_id => $layout_id) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "category_to_layout SET category_id = '" . (int)$category_id . "', store_id = '" . (int)$store_id . "', layout_id = '" . (int)$layout_id . "'");
			}
		}

		$this->saveCategoryPurchaseBlocks($category_id, $data);

		$this->cache->delete('category');
		$this->cache->deleteTag('catalog.category_counts', 'category_product_counts');
		
		if($this->config->get('config_seo_pro')){		
		$this->cache->delete('seopro');
		}
	}
	
	public function editCategoryStatus($category_id, $status) {
        $this->db->query("UPDATE " . DB_PREFIX . "category SET status = '" . (int)$status . "', date_modified = NOW() WHERE category_id = '" . (int)$category_id . "'");
        
		$this->cache->delete('category');
		$this->cache->deleteTag('catalog.category_counts', 'category_product_counts');
		
		if($this->config->get('config_seo_pro')){		
		$this->cache->delete('seopro');
		}
		
    }

	public function deleteCategory($category_id) {
		try { (new \CodeCart\Core\RelationLayer($this->registry))->invalidateProductRulesByCategory((int)$category_id); } catch (\Throwable $e) { $this->log->write('Relation invalidate category delete: ' . $e->getMessage()); }
		$this->db->query("DELETE FROM " . DB_PREFIX . "category_path WHERE category_id = '" . (int)$category_id . "'");

		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "category_path WHERE path_id = '" . (int)$category_id . "'");

		foreach ($query->rows as $result) {
			$this->deleteCategory($result['category_id']);
		}

		$this->db->query("DELETE FROM " . DB_PREFIX . "category WHERE category_id = '" . (int)$category_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "category_description WHERE category_id = '" . (int)$category_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "codecart_purchase_block WHERE owner_type = 'category' AND owner_id = '" . (int)$category_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "category_filter WHERE category_id = '" . (int)$category_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "category_to_store WHERE category_id = '" . (int)$category_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "category_to_layout WHERE category_id = '" . (int)$category_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "product_to_category WHERE category_id = '" . (int)$category_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "seo_url WHERE query = 'category_id=" . (int)$category_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "product_related_wb WHERE category_id = '" . (int)$category_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "article_related_wb WHERE category_id = '" . (int)$category_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "coupon_category WHERE category_id = '" . (int)$category_id . "'");

		try { (new \CodeCart\Core\RelationLayer($this->registry))->purgeEntity('category', (int)$category_id); } catch (\Throwable $e) { $this->log->write('Relation purge category: ' . $e->getMessage()); }

		$this->cache->delete('category');
		$this->cache->deleteTag('catalog.category_counts', 'category_product_counts');
		
		if($this->config->get('config_seo_pro')){		
		$this->cache->delete('seopro');
		}
	}

	public function repairCategories($parent_id = 0) {
		$parent_id = (int)$parent_id;

		// Rebuild the subtree in memory: one read of the category tree and
		// batched writes instead of several queries per category.
		$children = array();
		$query = $this->db->query("SELECT category_id, parent_id FROM " . DB_PREFIX . "category");

		foreach ($query->rows as $category) {
			$children[(int)$category['parent_id']][] = (int)$category['category_id'];
		}

		$parent_path = array();

		if ($parent_id) {
			$query = $this->db->query("SELECT path_id FROM `" . DB_PREFIX . "category_path` WHERE category_id = '" . $parent_id . "' ORDER BY level ASC");

			foreach ($query->rows as $result) {
				$parent_path[] = (int)$result['path_id'];
			}
		}

		$paths = array();
		$stack = array(array($parent_id, $parent_path));

		while ($stack) {
			list($node_id, $node_path) = array_pop($stack);

			if (empty($children[$node_id])) {
				continue;
			}

			foreach ($children[$node_id] as $category_id) {
				// A parent cycle in damaged data must not loop forever.
				if (isset($paths[$category_id]) || $category_id === $parent_id) {
					continue;
				}

				$path = $node_path;
				$path[] = $category_id;
				$paths[$category_id] = $path;
				$stack[] = array($category_id, $path);
			}
		}

		foreach (array_chunk(array_keys($paths), 500) as $chunk) {
			$this->db->query("DELETE FROM `" . DB_PREFIX . "category_path` WHERE category_id IN (" . implode(',', $chunk) . ")");

			$values = array();

			foreach ($chunk as $category_id) {
				foreach ($paths[$category_id] as $level => $path_id) {
					$values[] = "('" . $category_id . "', '" . $path_id . "', '" . $level . "')";
				}
			}

			$this->db->query("REPLACE INTO `" . DB_PREFIX . "category_path` (category_id, path_id, level) VALUES " . implode(', ', $values));
		}
	}

	public function getGoogleProductCategoryId($category_id, $visited = array()) {
		$category_id = (int)$category_id;
		if ($category_id <= 0 || isset($visited[$category_id])) {
			return '';
		}

		$visited[$category_id] = true;
		$query = $this->db->query("SELECT google_product_category_id, parent_id FROM `" . DB_PREFIX . "category` WHERE category_id = '" . $category_id . "' LIMIT 1");

		if (!$query->num_rows) {
			return '';
		}

		$value = preg_replace('/[^0-9]/', '', (string)$query->row['google_product_category_id']);
		if ($value !== '') {
			return $value;
		}

		return (int)$query->row['parent_id'] > 0 ? $this->getGoogleProductCategoryId((int)$query->row['parent_id'], $visited) : '';
	}


    private function saveCategoryPurchaseBlocks($category_id, $data) {
        if (!array_key_exists('purchase_block_mode', $data)) { return; }
        $category_id = (int)$category_id;
        $mode = isset($data['purchase_block_mode']) ? (string)$data['purchase_block_mode'] : 'inherit';
        if (!in_array($mode, array('inherit','custom','disabled'), true)) { $mode = 'inherit'; }
        $this->db->query("DELETE FROM " . DB_PREFIX . "codecart_purchase_block WHERE owner_type = 'category' AND owner_id = '" . $category_id . "'");
        if ($mode === 'inherit') { return; }
        if ($mode === 'disabled') {
            $this->db->query("INSERT INTO " . DB_PREFIX . "codecart_purchase_block SET owner_type='category', owner_id='" . $category_id . "', language_id='0', mode='2', data='[]'");
            return;
        }
        $this->db->query("INSERT INTO " . DB_PREFIX . "codecart_purchase_block SET owner_type='category', owner_id='" . $category_id . "', language_id='0', mode='1', data='[]'");
        $blocks = isset($data['purchase_blocks_json']) && is_array($data['purchase_blocks_json']) ? $data['purchase_blocks_json'] : array();
        foreach ($blocks as $language_id => $json) {
            $language_id = (int)$language_id;
            if ($language_id < 1) { continue; }
            $encoded = \CodeCart\Core\PurchaseBlocks::encode($json);
            $this->db->query("INSERT INTO " . DB_PREFIX . "codecart_purchase_block SET owner_type='category', owner_id='" . $category_id . "', language_id='" . $language_id . "', mode='1', data='" . $this->db->escape($encoded) . "'");
        }
    }

    public function getPurchaseBlocks($category_id) {
        $result = array('mode'=>'inherit','languages'=>array());
        $query = $this->db->query("SELECT language_id, mode, data FROM " . DB_PREFIX . "codecart_purchase_block WHERE owner_type='category' AND owner_id='" . (int)$category_id . "' ORDER BY language_id ASC");
        foreach ($query->rows as $row) {
            if ((int)$row['mode'] === 2) { $result['mode']='disabled'; $result['languages']=array(); return $result; }
            $result['mode']='custom';
            if ((int)$row['language_id'] > 0) { $result['languages'][(int)$row['language_id']] = (string)$row['data']; }
        }
        return $result;
    }

	public function getCategory($category_id) {
		$rows = $this->getCategoriesByIds(array((int)$category_id));

		return isset($rows[(int)$category_id]) ? $rows[(int)$category_id] : array();
	}

	/**
	 * getCategory() rows for several ids in one query, keyed by id.
	 */
	public function getCategoriesByIds(array $category_ids) {
		$ids = array_values(array_unique(array_filter(array_map('intval', $category_ids))));
		if (!$ids) {
			return array();
		}

		$query = $this->db->query("SELECT DISTINCT *, (SELECT GROUP_CONCAT(cd1.name ORDER BY level SEPARATOR '&nbsp;&nbsp;&gt;&nbsp;&nbsp;') FROM " . DB_PREFIX . "category_path cp LEFT JOIN " . DB_PREFIX . "category_description cd1 ON (cp.path_id = cd1.category_id AND cp.category_id != cp.path_id) WHERE cp.category_id = c.category_id AND cd1.language_id = '" . (int)$this->config->get('config_language_id') . "' GROUP BY cp.category_id) AS path FROM " . DB_PREFIX . "category c LEFT JOIN " . DB_PREFIX . "category_description cd2 ON (c.category_id = cd2.category_id) WHERE c.category_id IN (" . implode(',', $ids) . ") AND cd2.language_id = '" . (int)$this->config->get('config_language_id') . "'");

		$rows = array();
		foreach ($query->rows as $row) {
			$rows[(int)$row['category_id']] = $row;
		}

		return $rows;
	}
	
	public function getAllCategories() {
		$result = $this->cache->get('category.all.' . $this->config->get('config_language_id') . '.' . (int)$this->config->get('config_store_id'));

		if (!$result || !is_array($result)) {
			$query = $this->db->query("SELECT c.category_id, c.parent_id, name FROM " . DB_PREFIX . "category c LEFT JOIN " . DB_PREFIX . "category_description cd ON (c.category_id = cd.category_id) LEFT JOIN " . DB_PREFIX . "category_to_store c2s ON (c.category_id = c2s.category_id) WHERE cd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND c2s.store_id = '" . (int)$this->config->get('config_store_id') . "' ORDER BY c.parent_id, c.sort_order, cd.name");
		
			$categories = array();
		
			foreach ($query->rows as $row) {
				$categories[$row['parent_id']][$row['category_id']] = $row;
			}
		
			$result = $this->getCategories($categories);
		
			$this->cache->set('category.all.' . $this->config->get('config_language_id') . '.' . (int)$this->config->get('config_store_id'), $result);
		}

		return $result;
	}

	public function getCategories($data = array()) {
		$sql = "SELECT cp.category_id AS category_id, GROUP_CONCAT(cd1.name ORDER BY cp.level SEPARATOR '&nbsp;&nbsp;&gt;&nbsp;&nbsp;') AS name, c1.parent_id, c1.sort_order, c1.noindex FROM " . DB_PREFIX . "category_path cp LEFT JOIN " . DB_PREFIX . "category c1 ON (cp.category_id = c1.category_id) LEFT JOIN " . DB_PREFIX . "category c2 ON (cp.path_id = c2.category_id) LEFT JOIN " . DB_PREFIX . "category_description cd1 ON (cp.path_id = cd1.category_id) LEFT JOIN " . DB_PREFIX . "category_description cd2 ON (cp.category_id = cd2.category_id) WHERE cd1.language_id = '" . (int)$this->config->get('config_language_id') . "' AND cd2.language_id = '" . (int)$this->config->get('config_language_id') . "'";

		if (!empty($data['filter_name'])) {
			$sql .= " AND cd2.name LIKE '%" . $this->db->escape($data['filter_name']) . "%'";
		}

		$sql .= " GROUP BY cp.category_id";

		$sort_data = array(
			'name',
			'sort_order',
			'noindex'
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY sort_order";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$query = $this->db->query($sql);

		return $query->rows;
	}

	public function getCategoryDescriptions($category_id) {
		$category_description_data = array();

		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "category_description WHERE category_id = '" . (int)$category_id . "'");

		foreach ($query->rows as $result) {
			$category_description_data[$result['language_id']] = array(
				'name'             => $result['name'],
				'meta_title'       => $result['meta_title'],
				'meta_h1'      	   => $result['meta_h1'],
				'meta_description' => $result['meta_description'],
				'meta_keyword'     => $result['meta_keyword'],
				'description'      => $result['description']
			);
		}

		return $category_description_data;
	}
	
	public function getCategoryPath($category_id) {
		$query = $this->db->query("SELECT category_id, path_id, level FROM " . DB_PREFIX . "category_path WHERE category_id = '" . (int)$category_id . "'");

		return $query->rows;
	}
	
	public function getCategoryFilters($category_id) {
		$category_filter_data = array();

		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "category_filter WHERE category_id = '" . (int)$category_id . "'");

		foreach ($query->rows as $result) {
			$category_filter_data[] = $result['filter_id'];
		}

		return $category_filter_data;
	}

	public function getCategoryStores($category_id) {
		$category_store_data = array();

		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "category_to_store WHERE category_id = '" . (int)$category_id . "'");

		foreach ($query->rows as $result) {
			$category_store_data[] = $result['store_id'];
		}

		return $category_store_data;
	}
	
	public function getCategorySeoUrls($category_id) {
		$category_seo_url_data = array();
		
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "seo_url WHERE query = 'category_id=" . (int)$category_id . "'");

		foreach ($query->rows as $result) {
			$category_seo_url_data[$result['store_id']][$result['language_id']] = $result['keyword'];
		}

		return $category_seo_url_data;
	}
	
	
	public function getCategoryLayouts($category_id) {
		$category_layout_data = array();

		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "category_to_layout WHERE category_id = '" . (int)$category_id . "'");

		foreach ($query->rows as $result) {
			$category_layout_data[$result['store_id']] = $result['layout_id'];
		}

		return $category_layout_data;
	}

	public function getTotalCategories() {
		$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "category");

		return $query->row['total'];
	}
	
	public function getTotalCategoriesByLayoutId($layout_id) {
		$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "category_to_layout WHERE layout_id = '" . (int)$layout_id . "'");

		return $query->row['total'];
	}

	public function getAdminCategoryTreeRows() {
		$query = $this->db->query("SELECT c.category_id, c.parent_id, c.sort_order, c.noindex, cd.name FROM " . DB_PREFIX . "category c LEFT JOIN " . DB_PREFIX . "category_description cd ON (c.category_id = cd.category_id) WHERE cd.language_id = '" . (int)$this->config->get('config_language_id') . "' ORDER BY c.parent_id, c.sort_order, cd.name");
		$by_parent = array();
		foreach ($query->rows as $row) {
			$parent_id = (int)$row['parent_id'];
			$by_parent[$parent_id][] = $row;
		}
		return $by_parent;
	}

	public function getCategoriesByParentId($parent_id = 0) {
		$query = $this->db->query("SELECT *, (SELECT COUNT(parent_id) FROM " . DB_PREFIX . "category WHERE parent_id = c.category_id) AS children FROM " . DB_PREFIX . "category c LEFT JOIN " . DB_PREFIX . "category_description cd ON (c.category_id = cd.category_id) WHERE c.parent_id = '" . (int)$parent_id . "' AND cd.language_id = '" . (int)$this->config->get('config_language_id') . "' ORDER BY c.sort_order, cd.name");
		return $query->rows;
	}
	
	public function getCategoriesChildren($parent_id = 0) {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "category_path WHERE path_id = '" . (int)$parent_id . "'");
		return $query->rows;
	}
	
	public function getProductRelated($category_id) {
		$product_related_data = array();
		
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_related_wb WHERE category_id = '" . (int)$category_id . "'");
		
		foreach ($query->rows as $result) {
			$product_related_data[] = $result['product_id'];
		}
		
		return $product_related_data;
	}
	
	public function getArticleRelated($category_id) {
		$article_related_data = array();
		
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "article_related_wb WHERE category_id = '" . (int)$category_id . "'");
		
		foreach ($query->rows as $result) {
			$article_related_data[] = $result['article_id'];
		}
		
		return $article_related_data;
	}
}