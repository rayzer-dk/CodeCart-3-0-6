# Сторонні компоненти та ліцензії

Цей файл є зручним покажчиком основних сторонніх бібліотек і шрифтів у CodeCart PRO 3.0.6.0. Він не замінює оригінальні ліцензійні файли відповідних компонентів. Copyright notices та файли ліцензій усередині сторонніх пакетів необхідно зберігати.

| Компонент | Версія у збірці | Ліцензія | Офіційне джерело |
| --- | --- | --- | --- |
| OpenCart 3.x core portions | modified 3.x lineage | GNU GPL v3 | https://www.opencart.com/ |
| ocStore 3.x portions / SeoPro lineage | modified 3.x lineage | GNU GPL v3 | https://ocstore.com/ |
| Twig | v3.28.0 | BSD-3-Clause | https://twig.symfony.com/ |
| Guzzle | 7.15.5 | MIT | https://github.com/guzzle/guzzle |
| Guzzle Promises | 2.5.3 | MIT | https://github.com/guzzle/promises |
| Guzzle PSR-7 | 2.13.1 | MIT | https://github.com/guzzle/psr7 |
| Symfony Filesystem | v6.4.45 | MIT | https://symfony.com/ |
| Symfony Deprecation Contracts | v3.7.1 | MIT | https://symfony.com/ |
| Symfony Polyfill Mbstring | v1.38.2 | MIT | https://symfony.com/ |
| Symfony Polyfill Ctype | v1.37.0 | MIT | https://symfony.com/ |
| Symfony Polyfill PHP 8.0 | v1.37.0 | MIT | https://symfony.com/ |
| League URI | 7.8.1 | MIT | https://uri.thephpleague.com/ |
| League URI Interfaces | 7.8.1 | MIT | https://uri.thephpleague.com/ |
| PSR HTTP Message | 2.0 | MIT | https://www.php-fig.org/psr/psr-7/ |
| PSR HTTP Client | 1.0.3 | MIT | https://www.php-fig.org/psr/psr-18/ |
| PSR HTTP Factory | 1.1.0 | MIT | https://www.php-fig.org/psr/psr-17/ |
| scssphp | v2.1.0 | MIT | https://scssphp.github.io/scssphp/ |
| scssphp Source Span | v1.1.0 | MIT | https://github.com/scssphp/source-span |
| ralouphie/getallheaders | 3.0.3 | MIT | https://github.com/ralouphie/getallheaders |
| Composer-generated autoloader/runtime metadata | generated with Composer; Composer CLI is not shipped | MIT | https://getcomposer.org/ |
| jQuery | 3.7.1 | MIT | https://jquery.com/ |
| jQVMap world map geometry / compatibility library | 1.0 | MIT | https://jqvmap.com/ |
| Bootstrap | 3.4.1 | MIT | https://getbootstrap.com/docs/3.4/ |
| Font Awesome Free | 6.7.2 | Font: SIL OFL 1.1; code: MIT; icons: CC BY 4.0 | https://fontawesome.com/ |
| Summernote | 0.9.1 | MIT | https://summernote.org/ |
| CodeMirror | 5.65.21 | MIT | https://codemirror.net/5/ |
| PhotoSwipe | 5.4.4 | MIT | https://photoswipe.com/ |
| Moment.js | 2.30.1 | MIT | https://momentjs.com/ |
| SortableJS | 1.15.7 | MIT | https://sortablejs.github.io/Sortable/ |
| Magnific Popup | 1.2.0 | MIT | https://dimsemenov.com/plugins/magnific-popup/ |
| Inter font | bundled | SIL Open Font License 1.1 | https://rsms.me/inter/ |

Точні тексти ліцензій знаходяться у LICENSES/, у каталозі відповідного компонента або в обох місцях. Якщо цей покажчик відрізняється від оригінального licence notice компонента, для цього компонента пріоритет має його власна ліцензія.
