# CodeCart PRO 3.0.6.0

CodeCart PRO — модернізована e-commerce CMS на базі OpenCart/ocStore 3.x із збереженням практичної сумісності OpenCart 3, сучасним Core, PHP 8.1–8.5, InnoDB, utf8mb4, SEO foundation, безпечним Installer 2.0, Queue/Scheduler, сучасним dependency/QA-контуром і Compatibility Layer.

## Структура дистрибутива

Production-архів навмисно розділено на runtime і локальну документацію:

- upload/ — ЄДИНИЙ каталог, вміст якого потрібно копіювати у web root сайту;
- documentation/ — документація й ліцензії для локального читання; на сервер не потрібна;
- README_FIRST.txt — коротка пам’ятка про правильне розгортання.

QA/CI та source engineering tools постачаються ОКРЕМИМ архівом. .github, qa, provenance, composer.json, composer.lock, phpstan.neon.dist, .php-cs-fixer.dist.php та Docker-файли НЕ потрібно завантажувати у production web root.

Для clean install див. INSTALL.md. Для оновлення існуючого OpenCart/ocStore див. UPGRADE.md.

Перед встановленням або оновленням обов’язково створіть повний backup файлів і БД. Для production рекомендовано PHP 8.4/8.5, при цьому Core зберігає compatibility target PHP 8.1–8.5.

Підтримка: support@codecartpro.com
Сайт: https://codecartpro.com/
ВАЖНО: при обновлении не удаляйте config.php и admin/config.php. Загружайте содержимое upload поверх существующего сайта. Вход в админку выполняется по логину администратора, не по e-mail.
