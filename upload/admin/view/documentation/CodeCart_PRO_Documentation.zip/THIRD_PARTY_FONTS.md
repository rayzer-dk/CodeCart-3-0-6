# CodeCart PRO 3.0.6.0 — шрифти та їх ліцензування

Стандартна вітрина CodeCart PRO не завантажує Google Fonts, Adobe Fonts/Typekit або інший зовнішній font CDN. Більшість варіантів текстових шрифтів використовують системні CSS font stacks. Inter постачається локально як опціональний шрифт вітрини: Inter 3.019, ваги 400/500/700, WOFF2, font-display: swap.

CodeCart не завантажує власні файли Arial, Segoe UI, Roboto, Verdana, Tahoma, Trebuchet MS або Georgia — за наявності вони беруться з операційної системи користувача.

Локальні icon/UI fonts збережені для сумісності з OpenCart 3 modules/themes. Inter поширюється за SIL OFL 1.1. Font Awesome Free 6.7.2 використовує SIL OFL 1.1 для шрифтів, MIT для коду/CSS та CC BY 4.0 для іконок. Bootstrap 3 і Summernote code/CSS мають MIT-ліцензію. CAPTCHA використовує малий окремий subset Font Awesome Free 6.7.2 Solid, а не старий FA4 webfont.

Для роботи стандартної теми CodeCart не потрібна платна ліцензія на шрифт. Сторонні теми та модулі можуть самостійно підключати інші шрифти й не входять до цього твердження.

Див. LICENSES/SIL-OFL-1.1.txt і LICENSES/MIT.txt.
