# Вимоги до сервера CodeCart PRO 3.0.6.0

PHP: 8.1–8.5. Для нових production-встановлень рекомендовано PHP 8.4 або 8.5. PHP 8.1 зберігається як compatibility target для оновлення існуючих магазинів, а не як рекомендована нова production-гілка. Перевіряйте саме WEB/FPM-профіль сайту; CLI PHP для cron/worker перевіряється окремо.

База даних: MySQL або MariaDB з підтримкою InnoDB та utf8mb4.

Обов’язкові PHP-компоненти перевіряє Installer 2.0: MySQLi або PDO MySQL, GD, cURL, OpenSSL, ZLIB, ZIP, SimpleXML, mbstring, Fileinfo, DOM/XML, Hash, XMLWriter та JSON.

Рекомендується:

- HTTPS;
- storage поза публічним web root;
- OPcache;
- коректно налаштований PHP memory_limit та upload/post limits під реальні задачі магазину;
- cron/CLI для Scheduler і Queue;
- регулярні резервні копії файлів і БД;
- InnoDB для робочих таблиць;
- utf8mb4 для текстових таблиць і колонок;
- вимкнений display_errors у production із записом технічних помилок у захищений журнал.

## TLS policy

CodeCart outbound HTTPS/SMTP connections require TLS 1.2 or newer. TLS 1.0 and TLS 1.1 are intentionally excluded. TLS 1.3 is negotiated automatically when the local OpenSSL/libcurl stack and the remote service support it.

For inbound HTTPS, TLS policy is configured at the web server, reverse proxy or CDN layer, not in PHP or `.htaccess` application code. Recommended production policy:

nginx: `ssl_protocols TLSv1.2 TLSv1.3;`

Apache VirtualHost: `SSLProtocol -all +TLSv1.2 +TLSv1.3`

If Cloudflare or another CDN terminates TLS, configure the same minimum TLS version there and also keep the origin connection on TLS 1.2 or TLS 1.3.

Installer 2.0 and Upgrade Preflight block installation/update when the runtime cannot enforce TLS 1.2 for CodeCart outbound connections.
