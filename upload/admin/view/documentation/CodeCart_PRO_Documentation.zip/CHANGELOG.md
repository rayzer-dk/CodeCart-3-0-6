CodeCart PRO 3.0.6.0

## Build 1.2.5 — queue visibility, Auto Relation clarity, search hint and integrity/dark-mode fixes

Fixed:
- Global admin search typewriter data is now emitted as safely hex-escaped raw JSON; Twig can no longer HTML-escape the JSON quotes and silently break JSON.parse().
- Cron / Scheduler now shows the persistent background queue itself, including code, route, status, attempts, availability, last update and last error, with filtering, 10/25/50/100 page size, pagination and a “Run queue now” action. The UI explains that the queue worker is invoked by cron.php rather than existing as a separate scheduled-task row.
- Auto Relations links directly to Cron / Scheduler when relation jobs are waiting. Product/category/article “Auto pick” help now explicitly distinguishes standard manual relation fields from the separately generated Auto Relation Layer.
- Regenerated the release integrity manifest after the final release-file changes. Files shipped by CodeCart no longer appear as false “Changed Core files” immediately after installation/update, and QA now fails when a tracked release hash becomes stale.
- Dashboard-specific dark-mode surfaces have a local dark fallback and new cache-busters, preventing the SEO/Security/integrity sections from remaining light after switching the admin to Dark mode.
- Catalog import preflight and help now explicitly state the ID policy: IDs are preserved and matching target IDs are updated; this is safe for restore/migration of the same catalog lineage but is not a blind merge mode for unrelated stores.
- Completed the Russian Cron / Scheduler language file; it previously contained only the catalog-URL error string.

Compatibility / safety:
- Catalog transfer continues to use schema intersection, language-code and store-URL mapping, SEO compatibility conversion, relation/reference validation, an automatic pre-import SQL snapshot and non-destructive upsert semantics. Unsupported target columns/tables are reported rather than guessed.
- Upgrade remains guarded by Installer 2.0 preflight for supported OpenCart 3.x/ocStore 3.x sources; third-party OCMOD/manual core edits are reported as compatibility risks rather than silently merged.

QA:
- Added regressions for search JSON rendering, scheduler queue visibility/action and integrity-manifest freshness.

## Build 1.2.4 — storefront theme, DateTimePicker, compact listings and catalog export

Fixed:
- Clean installs now use the light storefront theme by default; the bundled demo migration changes only the old `system` default and does not overwrite an explicit merchant choice.
- CodeCart Hybrid DateTimePicker 1.8.3 keeps one deterministic bridge around Bootstrap DateTimePicker, preventing load-order switching between two clock UIs. Hours/minutes/seconds labels are consistently localized and decorated.
- Product question form is rendered as a separate full-width action block below wishlist, compare and share.
- Blog grid mode keeps two article cards per row on mobile.
- Catalog and blog sort/limit/view controls share one compact responsive toolbar on desktop and mobile; product compare remains a secondary row on narrow screens.
- Project-support copy now states that users choose any contribution amount they consider appropriate and comfortable.
- Product export now includes all product relation tables present in the install schema, including product-to-article, product-to-category-wall and product-to-manufacturer relations. Category export coverage is validated against every category table in the install schema.

QA:
- Added storefront UX/DateTimePicker regression coverage and catalog export schema-coverage checks.
- Presentation schema revision 15 covers the light-theme demo migration.

## Build 1.2.3 — admin search hint, Brands layout consistency and demo presentation fixes

Fixed:
- Animated global-search examples now remain visible while the empty search field is focused; typing still hides the hint immediately.
- Added the missing localized `text_extension` breadcrumb key to Category Wall, Brands and Featured Products in en-gb, ru-ru and uk-ua.
- Home layout now references the dedicated `manufacturer_wall` module instead of an opaque generic Carousel instance backed by the Manufacturers banner. The generic Carousel extension/module remains installed and available for compatibility.
- Brands & Manufacturers demo settings now match the intended carousel preset: 12 items, 6/4/2 columns, 180x90 contain images, autoplay 2000 ms, arrows, dots, loop and one-item stepping.
- HTC, Hewlett-Packard and Samsung use real logo assets; Dell, Samsung and Nintendo are correctly linked to the default store on clean install.
- Category Wall lower-right chevron is geometrically centered in its blue triangular corner.
- Homepage slideshow gains Samsung and Hewlett-Packard frames and deterministic 0-3 sort order in both bundled languages.

Upgrade behavior:
- Presentation schema revision 14 applies these presentation corrections only to `CodeCart Demo Store`; merchant storefront layouts and catalog content remain untouched.
- The obsolete demo-home assignment of the generic manufacturers Carousel is removed, but the Carousel extension and module record are preserved.

QA:
- Added regressions for focused-search typewriter behavior, localized extension breadcrumbs, real demo assets, category-corner alignment, homepage Brands assignment and slideshow images.

Added
Global admin search can search information pages, blog articles and installed modules when the administrator has the corresponding access permission.
Product administration filters for attributes, options, downloads and SEO URL, with autocomplete and active-filter indication.
Extension installer preflight conflict preview and persistent install journal with backups of overwritten files.
Safe SVG support in File Manager through strict DOM sanitization.
Dependency-free native SVG world-map renderer for the dashboard; Core no longer loads jQVMap.
Standalone regression tests for extension installer rollback/uninstall and SVG sanitization.
Conservative PHP-CS-Fixer 3.95.25 CI check for CodeCart-owned modern PHP/QA code.
Release validator gate preventing CodeCart Core from reintroducing Flot, jQVMap or external Chart.js dependencies while keeping legacy files available for extension compatibility.
Remembered File Manager directory across the main image selectors.
Source dependency manifests, locked dependency metadata, PHPStan configuration, Docker QA environment, GitHub Actions QA matrix and provenance registry.

Changed
Product list category filtering no longer rewrites SQL with regular expressions. It uses explicit EXISTS/NOT EXISTS predicates and shares the same filter builder with total counting.
Extension uninstall restores the original version of overwritten files; files modified after installation are preserved and reported instead of being deleted.
All SVG display/resize paths now generate a sanitized cache copy, including SVG files that existed before the File Manager sanitizer was introduced.
Global admin search enforces access permissions per result type.

Fixed
Duplicate filter_quantity and filter_status URL propagation in the product controller.
Unsafe extension overwrite/uninstall behavior that could remove a pre-existing file.

Security
SVG scripts, event handlers, foreignObject, embedded active content, CSS and external references are rejected or removed before storage.
Raw pre-existing SVG files are no longer returned by image resize fallbacks; unsafe SVG fails closed.
Extension install.xml is parsed without network access and installation file operations are journaled for rollback.

Compatibility
No clean-install profile selector was added. Existing OpenCart 3.x/ocStore 3.x extension compatibility remains the priority.

## Build package cleanup and OC+ selective backports

Changed:
- Production package now contains deployable `upload/` plus local `documentation/`; QA/CI/source tools are shipped separately and are not web-root files.
- Removed internal build number from the visible “Core / Compatibility → About” UI; the package build is identified by archive filename only.
- Optimized the OpenCart 3 Event dispatcher: exact triggers avoid regex and resolved handlers are cached per event for the current request while preserving early-return semantics.
- API/payment route-family checks in startup guards are now case-insensitive.
- INSTALL/UPGRADE/README explicitly document which files belong in production web root.

Reviewed but not adopted from OC+: Chart.js/jsVectorMap replacement libraries, Bootstrap 5, jQuery 4, Font Awesome 7, random per-request full cache scans, and other OpenCart 4-specific changes because CodeCart already has lighter/safer equivalents or the compatibility cost is not justified.

## Checkout and audit hardening

Fixed:
- Default accordion checkout now serializes every input/select/textarea instead of maintaining a fragile input-type whitelist. HTML5 `email`, `tel`, `number`, `url` and future input types can no longer silently disappear from checkout AJAX requests.
- The same robust serialization is used for product-option AJAX payloads in product, blog-related product and PayPal Smart Button flows.
- System notifications now use an atomic UNIQUE(code) upsert, removing the SELECT-then-INSERT race between concurrent requests.
- Mobile admin profile text is hidden on extra-small screens so the account dropdown no longer doubles the header height.
- Removed the stray period from the Ukrainian checkout page heading.

Verified as already fixed before this pass:
- `editSetting()` uses explicit strict-mode-safe writes with transaction rollback.
- Catalog transfer table discovery, store SSL metadata handling and XLSX sheet-name normalization no longer contain the previously reported defects.
- Google Merchant feed already emits `identifier_exists=no` when GTIN/MPN identifiers are absent.
- Product-question forms already use randomized per-form honeypot names.
- The log writer already degrades safely when the log file cannot be opened.
- Storefront mobile `#top-links` already contains the RC78 compact alignment/overflow fix.
- Adaptive CAPTCHA no longer embeds visual base64 payloads on ordinary form loads; the visual image is generated only when required.
## Catalog transfer idempotency

Fixed:
- Re-importing an exported catalog no longer fails with MySQL/MariaDB duplicate-key error 1062 on pure relation tables whose imported columns are entirely covered by a composite PRIMARY KEY.
- `CatalogTransfer::upsert()` now emits a harmless primary-key self-assignment when no non-key column exists, preserving strict error handling without using `INSERT IGNORE`.
- The fix is generic and covers current transfer relations such as `product_to_store`, `category_to_store`, `manufacturer_to_store`, `product_filter`, `category_filter`, `product_recurring`, `product_related`, `product_to_download`, `product_related_wb` and `product_related_mn`.

QA:
- Added a regression test that invokes the real CatalogTransfer upsert builder twice for pure relation tables.
- CI database smoke now executes the generated relation upsert twice against both MySQL and MariaDB and requires exactly one resulting relation row.


Auto Relation Layer QA
- Added static/runtime regression coverage for default-OFF behavior, generic idempotent relation upsert, manual-before-auto storefront ordering, standard product-Save semantics, bounded relevance score and absence of external HTTP dependencies.
- MySQL/MariaDB database-smoke executes the same relation twice and verifies a single updated row.


Relation Layer final hardening:
- Strict OFF behavior is enforced inside the RelationLayer API itself: disabled save/read/suggest/purge calls short-circuit before SQL.
- Disabling Auto Relations removes pending relation-generation queue jobs so they cannot unexpectedly resume later.
- Entities deleted while the feature is OFF do not trigger relation SQL; stale polymorphic rows are reconciled once when an administrator explicitly enables the feature again.
- Self-relations are rejected both by the public API and the internal upsert path.
- Relation preview/apply now escapes entity names before inserting them into admin HTML.
- Relation table-existence checks are cached within a batch worker, avoiding repeated INFORMATION_SCHEMA probes while generating article relations.
- Admin POST actions now validate user_token in addition to access/modify permissions.
- Presentation schema marker raised to 9. Completed stores now leave Migration before GET_LOCK/INFORMATION_SCHEMA work, removing migration reconciliation SQL from normal storefront/admin requests.
- Added regression coverage for strict OFF/no-SQL behavior, self-relation rejection and the zero-query steady-state migration fast path.

- Per-product regeneration is atomic: old rule relations are replaced inside a DB transaction, with rollback on failure.
- Public clearAuto() also respects OFF; the admin's explicit maintenance action uses a forced clear path.


## Build 1.1.9 — manual Auto Relation helpers, layout integrity and SEO URL completion

Added:
- “Auto pick” buttons beside the existing manual related-products and related-blog-articles fields in Product, Category and Blog Article editors. Suggestions reuse the existing OpenCart/ocStore manual relation fields and are saved only by the standard entity Save action.
- Category and blog-article relation previews; information pages are explicitly excluded from the Relation Layer.
- Parent-category article inheritance as a lower-priority signal after direct category relations.
- Layout integrity QA for all bundled clean-install layouts/routes/modules.
- Full clean-install SEO URL coverage for products, categories, manufacturers, information pages, blog articles and blog categories on all bundled active languages.
- Additive migration backfill that generates only missing/empty entity SEO URLs from entity names, with per-store/per-language uniqueness and without overwriting non-empty merchant aliases.
- Dashboard SEO diagnostics for information pages and blog categories without SEO URLs.

Changed:
- Clean-install automatic SEO URL generation is enabled by default for newly created catalog/blog entities; existing upgrades keep their saved preference.
- Related-content auto suggestions remain bounded by the configured product/article limits and never create hundreds of storefront cards.
- Presentation schema marker raised to 11 for the one-time SEO URL completion migration.

Fixed:
- Missing SEO URLs for 4 bundled information pages, all 10 bundled blog articles and all 3 bundled blog categories in both bundled languages (34 missing aliases total).
- Parent-category relation reason is now localized in en-gb, ru-ru and uk-ua.
- Removed legacy layout_module no-op rows (`code=0`) from clean-install layout data and added update-safe cleanup.
## Build 1.2.0 — admin search and safer upgrade workflow

Fixed:
- Rebuilt the admin global-search control as one consistent flex component; removed the duplicated legacy Search CSS block that overrode the new 42px control with the old 35px grey styles and caused incomplete fill/border mismatch.
- Search-type dropdown is no longer clipped by the search group and can open normally.
- Animated search hints now use a real character-by-character typewriter/backspace effect instead of swapping complete example strings.
- Admin stylesheet cache-buster updated so existing browsers receive the corrected search styles immediately after upgrade.

Installer/upgrade safety:
- Installer UI and completion screen now explicitly state that administration sign-in uses the administrator login name, not the e-mail address.
- Upgrade documentation now distinguishes normal overlay upgrade from full code-tree replacement and requires restoring the existing `config.php` and `admin/config.php` before opening the installer.
- Clean installation continues to reject a database prefix that already contains tables; an existing store cannot be silently overwritten by the clean installer.
- Presentation schema marker raised to 12 so stores that already received an intermediate schema-11 build rerun the additive pending presentation/data migrations once.

QA:
- Added admin-search regression coverage preventing duplicate legacy CSS, clipped dropdowns and whole-string hint rotation.
- Added installer-upgrade safety regression coverage for existing-prefix protection and username/e-mail guidance.


## Build 1.2.1 — Auto Relation UX, relation table, demo brands and SQL reset safety
- Auto Relation picker now shows the current selected count and the number newly added by auto selection.
- Relation fields keep full width when Auto Relation Layer is disabled.
- Auto Relations admin adds queue-state visibility plus a server-side table with search, filters, sorting, 25/50/100 limits, pagination, row selection and bulk enable/disable/delete.
- Clean-install demo adds Dell, Samsung and Nintendo manufacturers; missing HTC/HP manufacturer images are filled and all manufacturer assets are WebP.
- Manufacturer Wall remains available but is disabled and is not assigned to the Home layout by default; the standard Brands & Manufacturers page remains available.
- Installer SQL now has DROP TABLE IF EXISTS for every CREATE TABLE, including order_download and product_extra_tab.
- Documentation clarifies that install/opencart.sql is installer input, not a ready installed database dump and must not be imported over a live database.
- Presentation schema revision 13 updates existing CodeCart Demo Store instances only; merchant stores do not receive demo brands or layout changes.
