# CodeCart PRO dependency policy — 2026-09-14

CodeCart PRO keeps runtime dependencies only when they provide a concrete benefit that is not better served by the existing lightweight core. Major upgrades are not accepted only to increase version numbers; compatibility cost, PHP floor, security and measurable maintenance benefit are reviewed together.

## Runtime decisions for 3.0.6.0

- PHP target remains 8.1–8.5 for upgrade compatibility. PHP 8.1 is compatibility-only for existing environments; new production installations should prefer a currently supported branch, especially PHP 8.4 or 8.5. Raising the minimum only to PHP 8.2 is not planned because it provides little architectural benefit while PHP 8.2 itself reaches the end of security support on 2026-12-31.
- Twig stays on 3.28.0. Twig 4 is pre-release and requires PHP 8.2+, so it is not an appropriate production dependency for this branch.
- Guzzle stays on 7.15.5. Guzzle 8 is a separate major migration with PSR-7/Promises compatibility impact and is not required by current CodeCart functionality.
- scssphp stays on 2.1.0 and League URI stays on 7.8.1.
- Symfony Filesystem stays on the PHP 8.1-compatible 6.4 LTS line. Additional Symfony Cache, Config, Security, String, Validator or YAML components are not added unless a concrete CodeCart feature requires them.
- jQuery stays on 3.7.1 in the OpenCart 3 compatibility branch. jQuery 4 has breaking changes and would unnecessarily increase extension compatibility risk.
- PSR HTTP interfaces remain the versions required by the locked Guzzle stack. New PSR abstractions are not added without an actual use case.
- AWS SDK is not part of Core. S3/SES integrations should be optional extensions because the SDK materially increases the dependency tree.
- PHPMailer is not added merely to replace the existing mail layer. A migration would require separate SMTP/mail regression testing and compatibility work.
- PHPUnit is not shipped in runtime. It may be introduced as a development dependency when the unit-test suite grows enough to justify the additional toolchain; current critical regression tests are standalone integration tests.

## Frontend/admin decisions

- Dashboard charts use the dependency-free CodeCart SVG chart renderer. Flot remains only at its historical path for third-party OpenCart 3 extension compatibility; CodeCart Core does not load it.
- Dashboard world map uses the dependency-free CodeCart SVG world-map renderer. The old jQVMap files remain only for legacy extension compatibility; CodeCart Core does not load jQVMap.
- Chart.js and jsVectorMap are therefore not added to Core because they would increase payload/dependency surface without a current functional gain.

## Development and QA tools

- Composer 2.10.x is the expected build/CI dependency manager; composer.phar is not included in the production distribution.
- PHPStan is locked at 2.2.14 in composer.lock and runs in CI.
- PHP-CS-Fixer is pinned to 3.95.25 in CI and is deliberately scoped to CodeCart-owned modern PHP and QA code. It is not allowed to mass-reformat the OpenCart/ocStore legacy compatibility tree.
- Composer validate, dependency integrity validation and Composer security audit are release gates.
