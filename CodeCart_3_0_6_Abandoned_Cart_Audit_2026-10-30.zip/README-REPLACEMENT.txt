CodeCart 3.0.6 abandoned carts: phone column, SQL source adapter, guest contact field mapping.
Back up the entire site and database before updating. Copy upload/ to your store root.
Clear modifications cache, Twig cache and PHP OPcache if configured.
The default OpenCart cart source works for most themes and checkout modules.
External SQL source is read-only and cannot send reminder emails.
Guest contact collection requires explicit checkbox consent, valid email and an enabled module.
Custom checkout routes with AJAX form inputs can be mapped using CSS selectors.
This ZIP is a file replacement, not a complete production build.
