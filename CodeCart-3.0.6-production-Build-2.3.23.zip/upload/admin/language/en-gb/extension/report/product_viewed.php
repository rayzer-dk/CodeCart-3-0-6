<?php
// Heading
$_['heading_title']    = 'Products Viewed Report';

// Text
$_['text_extension']   = 'Extensions';
$_['text_edit']        = 'Edit Products Viewed Report';
$_['text_success']     = 'Success: You have reset the products viewed report!';

// Column
$_['column_name']      = 'Product Name';
$_['column_model']     = 'Model';
$_['column_viewed']    = 'Viewed';
$_['column_percent']   = 'Percent';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sort Order';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify products viewed report!';
// CodeCart PRO: aligned locale keys
$_['text_list'] = 'Feed List';
$_['text_filter'] = 'Filter';
