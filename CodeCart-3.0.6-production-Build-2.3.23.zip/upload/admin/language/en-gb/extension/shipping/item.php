<?php
// Heading
$_['heading_title']    = 'Per Item';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified shipping per item rates!';
$_['text_edit']        = 'Edit Per Item Shipping';

// Entry
$_['entry_cost']       = 'Cost';
$_['entry_tax_class']  = 'Tax Class';
$_['entry_geo_zone']   = 'Geo Zone';
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sort Order';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify shipping per item rates!';
// CodeCart PRO: aligned locale keys
$_['text_shipping'] = 'Shipping';
