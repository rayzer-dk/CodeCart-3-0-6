<?php
// Heading
$_['heading_title']    = 'Store Credit';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified store credit total!';
$_['text_edit']        = 'Edit Store Credit Total';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sort Order';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify store credit total!';
// CodeCart PRO: aligned locale keys
$_['text_total'] = 'Order Totals';
