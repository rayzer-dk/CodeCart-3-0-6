<?php
$_['text_blog_display'] = 'Storefront display';
$_['entry_blog_show_date'] = 'Show publication date';
$_['entry_blog_show_reviews'] = 'Show reviews and rating';
$_['entry_blog_show_views'] = 'Show view count';
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']                    = 'Setting Blog';

// Text
$_['text_success']                     = 'Success: You have modified setting blog!';
$_['text_edit']                        = 'Edit Setting blog';
$_['text_article']                     = 'articles';
$_['text_review']                      = 'Reviews';

// Entry
$_['entry_article_limit']              = 'Default Items Per Page (Catalog)';
$_['entry_article_description_length'] = 'List Description Limit (Catalog)';
$_['entry_limit_admin']                = 'Default Items Per Page (Admin)';
$_['entry_article_count']              = 'Category article Count';
$_['entry_blog_menu']                       = 'Top menu';
$_['entry_article_download']                   = 'Allow downloads';
$_['entry_review']                     = 'Allow Reviews';
$_['entry_review_guest']               = 'Allow Guest Reviews';
$_['entry_review_mail']                = 'New Review Alert Mail';
$_['entry_image_category']             = 'Category Image Size';
$_['entry_image_article']              = 'article Image List Size';
$_['entry_image_related']              = 'Related article Image Size';
$_['entry_width']                      = 'Width';
$_['entry_height']                     = 'Height';
$_['entry_name']                       = 'Name';
$_['entry_meta_title']                 = 'Meta Title';
$_['entry_html_h1']                    = 'Html Tag H1';
$_['entry_meta_description']           = 'Meta Tag Description';
$_['entry_meta_keyword']               = 'Meta Tag Keywords';

// Help
$_['help_article_limit'] 	           = 'Determines how many catalog items are shown per page (articles, etc).';
$_['help_article_description_length']  = 'In the list view, short description character limit (categories, etc).';
$_['help_limit_admin']   	           = 'Determines how many admin items are shown per page (articles, categories, etc).';
$_['help_article_count']               = 'Show the number of articles inside the subcategories in the storefront header category menu. Be warned, this will cause an extreme performance hit for stores with a lot of subcategories!';
$_['help_blog_menu']       	           = 'Show the top horizontal menu link on the blog.';
$_['help_review']       	           = 'Enable/Disable new review entry and display of existing reviews.';
$_['help_review_guest']       	       = 'Allow guests to post reviews.';
$_['help_review_mail']                 = 'Send an email to the store owner when a new review is created.';

// Error
$_['error_warning']                    = 'Warning: Please check the form carefully for errors!';
$_['error_permission']                 = 'Warning: You do not have permission to modify settings!';
$_['error_limit']       	           = 'Limit required!';
$_['error_image_article']              = 'Article List Size dimensions required!';
$_['error_image_category']             = 'Category List Size dimensions required!';
$_['error_image_related']              = 'Related article Image Size dimensions required!';
$_['help_comment'] = 'This field is for any special notes you would like to tell the customer i.e. Store does not accept cheques.';
