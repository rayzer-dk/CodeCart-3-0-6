<?php
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']          = 'Products';

// Text
$_['text_success']           = 'Success: You have modified products!';
$_['text_list']              = 'Product List';
$_['text_products_per_page'] = 'Per page';
$_['text_add']               = 'Add Product';
$_['text_edit']              = 'Edit Product';
$_['text_filter']            = 'Filter';
$_['text_plus']              = '+';
$_['text_minus']             = '-';
$_['text_default']           = 'Default';
$_['text_option']            = 'Option';
$_['text_option_value']      = 'Option Value';
$_['text_percent']           = 'Percentage';
$_['text_amount']            = 'Fixed Amount';
$_['text_keyword']           = 'Do not use spaces, instead replace spaces with - and make sure the SEO URL is globally unique.';

// Column
$_['column_name']            = 'Product Name';
$_['column_model']           = 'Model';
$_['column_image']           = 'Image';
$_['column_price']           = 'Price';
$_['column_quantity']        = 'Quantity';
$_['column_status']          = 'Status';
$_['column_noindex']         = 'Index';
$_['column_action']          = 'Action';

// Entry
$_['entry_name']             = 'Product Name';
$_['entry_description']      = 'Description';
$_['entry_meta_title']       = 'Meta Tag Title';
$_['entry_meta_h1']       	 = 'Meta Tag H1';
$_['entry_meta_keyword']     = 'Meta Tag Keywords';
$_['entry_meta_description'] = 'Meta Tag Description';
$_['entry_store']            = 'Stores';
$_['entry_keyword']          = 'Keyword';
$_['entry_model']            = 'Model';
$_['entry_sku']              = 'SKU';
$_['entry_upc']              = 'UPC';
$_['entry_ean']              = 'EAN';
$_['entry_jan']              = 'JAN';
$_['entry_isbn']             = 'ISBN';
$_['entry_mpn']              = 'MPN';
$_['entry_location']         = 'Location';
$_['entry_shipping']         = 'Requires Shipping';
$_['entry_manufacturer']     = 'Manufacturer';
$_['entry_date_available']   = 'Date Available';
$_['entry_quantity']         = 'Quantity';
$_['entry_minimum']          = 'Minimum Quantity';
$_['entry_stock_status']     = 'Out Of Stock Status';
$_['entry_price']            = 'Price';
$_['entry_tax_class']        = 'Tax Class';
$_['entry_points']           = 'Points';
$_['entry_option_points']    = 'Points';
$_['entry_subtract']         = 'Subtract Stock';
$_['entry_weight_class']     = 'Weight Class';
$_['entry_weight']           = 'Weight';
$_['entry_dimension']        = 'Dimensions (L x W x H)';
$_['entry_length_class']     = 'Length Class';
$_['entry_length']           = 'Length';
$_['entry_width']            = 'Width';
$_['entry_height']           = 'Height';
$_['entry_image']            = 'Image';
$_['entry_additional_image'] = 'Additional Images';
$_['entry_customer_group']   = 'Customer Group';
$_['entry_date_start']       = 'Date Start';
$_['entry_date_end']         = 'Date End';
$_['entry_priority']         = 'Priority';
$_['entry_attribute']        = 'Attribute';
$_['entry_attribute_group']  = 'Attribute Group';
$_['entry_text']             = 'Text';
$_['entry_option']           = 'Option';
$_['entry_option_value']     = 'Option Value';
$_['entry_required']         = 'Required';
$_['entry_status']           = 'Status';
$_['entry_sort_order']       = 'Sort Order';
$_['entry_category']         = 'Categories';
$_['entry_sub_category']     = 'include subcategories';
$_['entry_min']              = 'From';
$_['entry_max']              = 'To';
$_['entry_filter']           = 'Filters';
$_['entry_download']         = 'Downloads';
$_['entry_related']          = 'Related Products';
$_['entry_related_article']  = 'Related Articles';
$_['entry_tag']              = 'Product Tags';
$_['entry_reward']           = 'Reward Points';
$_['entry_layout']           = 'Layout Override';
$_['entry_recurring']        = 'Recurring Profile';
$_['entry_main_category']    = 'Main Category';
$_['entry_noindex']          = 'Index';

// Help
$_['help_sku']               = 'Stock Keeping Unit';
$_['help_upc']               = 'Universal Product Code';
$_['help_ean']               = 'European Article Number';
$_['help_jan']               = 'Japanese Article Number';
$_['help_isbn']              = 'International Standard Book Number';
$_['help_mpn']               = 'Manufacturer Part Number';
$_['help_manufacturer']      = '(Autocomplete)';
$_['help_minimum']           = 'Force a minimum ordered amount';
$_['help_stock_status']      = 'Status shown when a product is out of stock';
$_['help_points']            = 'Number of points needed to buy this item. If you don\'t want this product to be purchased with points leave as 0.';
$_['help_category']          = '(Autocomplete)';
$_['help_filter']            = '(Autocomplete)';
$_['help_download']          = '(Autocomplete)';
$_['help_related']           = '(Autocomplete)';
$_['help_tag']               = 'Comma separated';
$_['help_main_category']     = 'Select main category';
$_['help_noindex']           = 'Indexing in the search engines Google,  Bing and others';

// Error
$_['error_warning']          = 'Warning: Please check the form carefully for errors!';
$_['error_permission']       = 'Warning: You do not have permission to modify products!';
$_['error_name']             = 'Product Name must be greater than 1 and less than 255 characters!';
$_['error_meta_title']       = 'Meta Title must be greater than 1 and less than 255 characters!';
$_['error_model']            = 'Product Model must be greater than 1 and less than 64 characters!';
$_['error_keyword']          = 'SEO URL already in use!';
$_['error_unique']           = 'SEO URL must be unique!';
$_['button_image_multiple'] = 'Select multiple images';
$_['button_image_drag'] = 'Drag to reorder';
$_['button_image_main'] = 'Make main image';

$_['help_shipping'] = 'For a digital product select No and add the protected file under Links → Downloads. Delivery steps are skipped automatically. The customer must use an account, and the download is released only after the order reaches a Complete status.';

// CodeCart PRO product delivery type
$_['text_shipping_required'] = 'Physical / hybrid — shipping required';
$_['text_shipping_not_required'] = 'Digital / service — no shipping';

$_['help_download_updates'] = 'A completed purchase grants access to the downloads currently attached to this product. You may replace the file in an existing Download record or attach a new Download record for a new version; previous buyers will see the current files. The purchase-time snapshot remains a fallback if all current downloads are removed.';

$_['entry_google_product_category_id'] = 'Google Product Category ID';
$_['help_google_product_category_id'] = 'Numeric Google Product Taxonomy ID for Merchant feeds. Leave empty to inherit it from the product\'s main or nearest parent category.';

// CodeCart PRO product extra tab
$_['tab_extra'] = 'Extra tab';
$_['entry_extra_tab_mode'] = 'Extra product tab';
$_['text_extra_tab_global'] = 'Use global tab';
$_['text_extra_tab_custom'] = 'Custom for this product';
$_['text_extra_tab_disabled'] = 'Do not show for this product';
$_['entry_extra_tab_title'] = 'Tab title';
$_['entry_extra_tab_content'] = 'Tab content';
$_['help_extra_tab_mode'] = 'Use the store-wide tab, replace it for this product, or hide it only for this product.';
$_['error_extra_tab_title'] = 'Extra tab title must not exceed 128 characters!';
$_['button_extra_tab_global'] = 'Use the store-wide extra tab for selected products';
$_['button_extra_tab_hidden'] = 'Hide the extra tab for selected products';
$_['text_extra_tab_bulk_global_success'] = 'Extra tab mode changed to global for %s selected product(s).';
$_['text_extra_tab_bulk_hidden_success'] = 'Extra tab hidden for %s selected product(s).';

// CodeCart PRO compatibility-safe product taxonomy shortcuts.
$_['text_attribute_quick_tools'] = 'Quick attribute workflow';
$_['help_attribute_quick_tools'] = 'Create or open the native attribute manager in a new tab, then add the attribute through the normal product autocomplete. Product saving remains native.';
$_['button_attribute_create'] = 'Create attribute';
$_['button_attribute_manage'] = 'Attribute manager';
$_['text_option_quick_tools'] = 'Quick option workflow';
$_['help_option_quick_tools'] = 'Create the option in the native manager in a new tab, then find it in this product. Database structure and the normal OpenCart save flow are unchanged.';
$_['button_option_create'] = 'Create option';
$_['button_option_manage'] = 'Option manager';

$_['entry_tax_display_mode'] = "VAT display for this product";
$_['help_tax_display_mode'] = "Overrides the global storefront VAT display only for this product. It does not change checkout or tax calculation.";
$_['text_tax_display_inherit'] = "Use global setting";
$_['text_tax_display_native'] = "Native OpenCart display";
$_['text_tax_display_none'] = "Primary price only";
$_['text_tax_display_gross_net'] = "Price incl. VAT + excl. VAT";
$_['text_tax_display_gross_tax'] = "Price incl. VAT + VAT amount";
$_['text_tax_display_net_gross'] = "Price excl. VAT + incl. VAT";

// CodeCart PRO inherited purchase-area information blocks.
$_['tab_purchase_blocks'] = 'Content blocks';
$_['entry_purchase_block_mode'] = 'Content blocks';
$_['text_purchase_block_inherit'] = 'Inherit from main / parent category';
$_['text_purchase_block_custom'] = 'Add product blocks';
$_['text_purchase_block_disabled'] = 'Do not show';
$_['help_purchase_block_mode'] = 'Inherit category blocks, append product-specific blocks, or disable everything only for this product. Explicit product blocks override a category Do not show setting.';
$_['help_purchase_block_inheritance'] = 'The product inherits blocks from the nearest configured main category and then its parents. If no ancestor defines blocks, nothing is shown. Product-specific blocks are appended after inherited blocks.';
$_['text_purchase_block_builder'] = 'Block builder';
$_['text_purchase_block_info'] = 'Information / HTML block';
$_['text_purchase_block_size_table'] = 'Size table';
$_['text_purchase_block_sizes'] = 'Sizes';
$_['text_purchase_block_colors'] = 'Colours';
$_['entry_purchase_block_title'] = 'Title';
$_['entry_purchase_block_content'] = 'Content';
$_['entry_purchase_block_columns'] = 'Columns, one per line';
$_['entry_purchase_block_rows'] = 'Table rows; separate cells with |';
$_['entry_purchase_block_item_label'] = 'Label';
$_['entry_purchase_block_item_value'] = 'Value';
$_['button_purchase_block_add_item'] = 'Add row';
$_['button_purchase_block_up'] = 'Move up';
$_['button_purchase_block_down'] = 'Move down';
$_['text_purchase_block_empty'] = 'No blocks yet. Add the required block type above.';
$_['button_purchase_block_add_info'] = 'Info';
$_['button_purchase_block_add_size_table'] = 'Size table';
$_['button_purchase_block_add_sizes'] = 'Sizes';
$_['button_purchase_block_add_colors'] = 'Colours';
$_['help_purchase_block_builder'] = 'Data is saved only with the standard product/category Save button. Native OpenCart options and attributes are not changed.';

$_['text_purchase_block_form'] = 'Form / CTA';
$_['entry_purchase_block_form'] = 'Form';
$_['entry_purchase_block_form_display'] = 'Display';
$_['entry_purchase_block_form_button_text'] = 'Button text';
$_['button_purchase_block_add_form'] = 'Form';
$_['text_purchase_block_form_inline'] = 'Show form inline';
$_['text_purchase_block_form_button'] = 'Button + modal';
$_['warning_purchase_blocks_master'] = 'Blocks are saved, but storefront output is disabled globally in CodeCart Theme settings.';
$_['button_purchase_blocks_settings'] = 'Open theme settings';
$_['button_purchase_blocks_forms'] = 'Manage forms';

$_['button_generate_seo_url'] = 'Generate SEO URL';

$_['text_purchase_block_templates'] = 'Templates';
$_['text_purchase_block_preset_delivery'] = 'Delivery terms';
$_['text_purchase_block_preset_instruction'] = 'Usage instructions';
$_['text_purchase_block_preset_rules'] = 'Rules / important information';
$_['text_purchase_block_preset_shoes_eu'] = 'EU shoe size chart';
$_['text_purchase_block_preset_women_eu'] = 'EU women clothing sizes';
$_['text_purchase_block_preset_men_eu'] = 'EU men clothing sizes';

// CodeCart PRO product list filters
$_['entry_seo_url'] = 'SEO URL';

$_['button_relation_suggest'] = 'Auto pick';
$_['button_relation_selected'] = 'Generate auto relations for selected';
$_['button_add_selected'] = 'Add selected to form';
$_['text_relation_products'] = 'Suggested products';
$_['text_relation_articles'] = 'Suggested articles';
$_['text_relation_score'] = 'Relevance';
$_['text_relation_added'] = 'Suggestions added to the form. Use the standard Save button to persist them.';

$_['text_relation_button_help'] = 'Automatically picks suggestions into the standard manual fields. This is a form-filling helper, not an Auto Relation Layer write. Changes are applied only after the normal form save.';
$_['text_relation_autofill_result'] = 'Auto pick added to the manual field: %a. Selected now: %t. Limit: %m. Click Save. Auto Relation Layer is generated separately through the background queue.';
$_['text_relation_selected_count'] = 'Selected in this field: %t. Auto-selection limit: %m.';
$_['text_none_category'] = ' --- No category --- ';
$_['text_none_manufacturer'] = ' --- No manufacturer --- ';

$_['text_stock_notify_waiting'] = 'Waiting for stock';

$_['entry_purchase_block_form_icon'] = 'Button icon';
$_['entry_purchase_block_form_bg'] = 'Button background';
$_['entry_purchase_block_form_text_color'] = 'Text color';
$_['entry_purchase_block_form_hover_bg'] = 'Hover background';
$_['entry_purchase_block_enabled'] = 'Show block';
$_['button_purchase_block_add_existing_form'] = 'Add selected';
$_['text_purchase_block_choose_form'] = '— Choose an existing form / block —';
$_['error_meta_h1'] = 'HTML H1 tag must be between 0 and 255 characters!';
$_['text_action'] = 'Action';
$_['js_purchase_presets_json'] = '{}';

$_['tab_public_documents'] = 'Documents';
$_['entry_public_document'] = 'Public documents';
$_['help_public_document'] = 'Select previously uploaded documents by name. These are free files, separate from paid digital downloads.';
$_['text_manage_public_documents'] = 'Manage documents';
$_['text_unlink_public_document'] = 'Remove document link';

// CodeCart PRO: aligned locale keys
$_['column_category'] = 'Category';
$_['column_manufacturer'] = 'Manufacturer';
$_['entry_description_mini'] = 'Short description:';
$_['entry_heading'] = 'Heading';
$_['help_keyword'] = 'Do not use spaces, instead replace spaces with - and make sure the keyword is globally unique.';
$_['text_corner0'] = 'Top left';
$_['text_corner1'] = 'Top right';
$_['text_corner2'] = 'Bottom left';
$_['text_corner3'] = 'Bottom right';
$_['entry_sticker'] = 'Promo stickers';
$_['text_benefits'] = 'Benefits:';
$_['error_tab'] = 'Enter a tab name';
$_['button_quick_price_edit'] = 'Edit price';
$_['button_quick_price_save'] = 'Save price';
$_['button_quick_price_cancel'] = 'Cancel';
$_['text_quick_price_saved'] = 'Price saved.';
$_['error_quick_price_load'] = 'Failed to load price.';
$_['error_quick_price_save'] = 'Failed to save price.';
$_['error_quick_price_value'] = 'Enter a valid non-negative price (up to 4 decimal places).';
$_['error_quick_price_disabled'] = 'Quick price editing is disabled.';
$_['error_quick_price_request'] = 'Invalid price request.';
$_['error_quick_price_not_found'] = 'Product not found.';
$_['text_quick_on'] = 'On';
$_['text_quick_off'] = 'Off';
$_['text_quick_status_tooltip'] = 'Toggle product visibility on the storefront';
$_['text_quick_index_tooltip'] = 'Allow or block search engine indexing of this product';
$_['text_quick_quantity_edit'] = 'Edit stock quantity';
$_['error_quick_quantity_value'] = 'Enter a whole stock quantity from 0 to 2,147,483,647.';
$_['error_quick_field_value'] = 'Invalid value for product field.';
$_['error_quick_field_conflict'] = 'This product has been changed elsewhere. Reload the page and try again.';
$_['button_bulk_edit'] = 'Bulk edit';
$_['button_bulk_undo'] = 'Undo last bulk edit';
$_['button_bulk_apply'] = 'Apply to selected';
$_['button_cancel'] = 'Cancel';
$_['text_bulk_help'] = 'Applies to the products ticked in the list. Leave a field on "No change" to keep it.';
$_['text_bulk_no_change'] = 'No change';
$_['text_bulk_set'] = 'Set to';
$_['text_bulk_percent'] = 'Change by percent (e.g. 10 or -5)';
$_['text_bulk_amount'] = 'Add amount (e.g. 50 or -20)';
$_['text_bulk_add'] = 'Add (negative to subtract)';
$_['text_bulk_manufacturer'] = 'Manufacturer';
$_['text_bulk_no_manufacturer'] = '- none -';
$_['text_bulk_category'] = 'Category';
$_['text_bulk_confirm'] = 'Apply this change to all selected products?';
$_['text_bulk_undo_confirm'] = 'Revert the last bulk edit? Fields edited since then are kept.';
$_['text_bulk_success'] = 'Bulk edit applied: %d of %d selected products changed.';
$_['text_bulk_undo_success'] = 'Bulk edit reverted (%d values restored).';
$_['error_bulk_value'] = 'Warning: the bulk edit value is not valid.';
$_['error_bulk_selection'] = 'Warning: select from 1 to 1000 products.';
$_['error_bulk_nothing'] = 'Warning: choose what to change.';
$_['error_bulk_undo_none'] = 'Warning: there is no bulk edit to undo.';

$_['button_bulk_category'] = 'Add or move to a category';
$_['text_bulk_category_help'] = 'Applies to the products ticked in the list.';
$_['text_bulk_category_filter'] = 'Find a category';
$_['text_bulk_category_add'] = 'Add to the category (the products keep their current categories)';
$_['text_bulk_category_move'] = 'Move: keep only this category';
$_['text_bulk_category_move_confirm'] = 'All other categories of the selected products will be removed. Continue? You can undo it with the undo button for the last bulk change.';
$_['error_bulk_category'] = 'Select a category.';
